import React, { useState, useEffect } from "react";
import {
  Users, Palette, Image, User, Settings, LogOut,
  ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  Eye, Edit, Trash2
} from "lucide-react";
import { Link, Routes, Route, useNavigate } from "react-router-dom";
import "./adminnavbar.css";
import AdminHome from "./AdminHome";
import { useAuth } from "../contextapi/AuthContext";

export default function AdminNavBar() {
  const { setIsAdminLoggedIn, setIsUserLoggedIn, setIsArtistLoggedIn } = useAuth();
  const navigate = useNavigate();

  const [isCollapsed, setIsCollapsed] = useState(false);
  const [activeSection, setActiveSection] = useState('dashboard');
  const [expandedMenus, setExpandedMenus] = useState({
    users: false,
    artists: false,
    artworks: false,
  });
  const [hoveredItem, setHoveredItem] = useState(null);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) setIsCollapsed(true);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const toggleMenu = (menu) => {
    if (!isCollapsed) {
      setExpandedMenus((prev) => ({ ...prev, [menu]: !prev[menu] }));
    }
  };

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    setIsUserLoggedIn(false);
    setIsArtistLoggedIn(false);

    localStorage.setItem("isAdminLoggedIn", "false");
    localStorage.setItem("isUserLoggedIn", "false");
    localStorage.setItem("isArtistLoggedIn", "false");
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("username");

    navigate("/login");
  };

  const menuItems = [
    {
      id: 'users',
      label: 'Users Management',
      icon: Users,
      subItems: [
        { id: 'view-users', label: 'View All Users', icon: Eye, path: '/admin/users/view' },
        { id: 'update-users', label: 'Update Users', icon: Edit, path: '/admin/users/update' },
        { id: 'delete-users', label: 'Delete Users', icon: Trash2, path: '/admin/users/delete' }
      ]
    },
    {
      id: 'artists',
      label: 'Artists Management',
      icon: Palette,
      subItems: [
        { id: 'view-artists', label: 'View All Artists', icon: Eye, path: '/admin/artists/view' },
        { id: 'update-artists', label: 'Update Artists', icon: Edit, path: '/admin/artists/update' },
        { id: 'delete-artists', label: 'Delete Artists', icon: Trash2, path: '/admin/artists/delete' }
      ]
    },
    {
      id: 'artworks',
      label: 'Artworks Management',
      icon: Image,
      subItems: [
        { id: 'view-artworks', label: 'View All Artworks', icon: Eye, path: '/admin/artworks/view' },
        { id: 'update-artworks', label: 'Update Artworks', icon: Edit, path: '/admin/artworks/update' },
        { id: 'delete-artworks', label: 'Delete Artworks', icon: Trash2, path: '/admin/artworks/delete' }
      ]
    }
  ];

  const singleItems = [
    { id: 'profile', label: 'Profile', icon: User, path: '/admin/profile' },
    { id: 'settings', label: 'Settings', icon: Settings, path: '/admin/settings' }
  ];

  return (
    <div className="admin-layout">
      <aside className={`admin-navbar ${isCollapsed ? "collapsed" : "expanded"}`}>
        <div className="admin-header">
          {!isCollapsed && (
            <div className="admin-logo" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div className="admin-logo-box">
                <Palette size={20} color="white" />
              </div>
              <div>
                <h1 className="admin-title">Art Gallery</h1>
                <p className="admin-subtitle">Admin Panel</p>
              </div>
            </div>
          )}
          <button
            className="admin-collapse-btn"
            onClick={() => setIsCollapsed(!isCollapsed)}
          >
            {isCollapsed ? <ChevronRight size={16} color="#94a3b8" /> : <ChevronLeft size={16} color="#94a3b8" />}
          </button>
        </div>

        <div className="admin-menu">
          <Link 
            to="/admin/home" 
            className={`menu-item ${activeSection === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveSection('dashboard')}
            onMouseEnter={() => setHoveredItem('dashboard')}
            onMouseLeave={() => setHoveredItem(null)}
          >
            <Users size={20} style={{ 
              color: activeSection === 'dashboard' || hoveredItem === 'dashboard' ? '#22d3ee' : '#94a3b8'
            }} />
            {!isCollapsed && <span>Dashboard</span>}
          </Link>

          {menuItems.map((item) => (
            <div key={item.id}>
              <div 
                onClick={() => toggleMenu(item.id)} 
                className={`menu-item ${activeSection === item.id ? 'active' : ''}`}
                onMouseEnter={() => setHoveredItem(item.id)}
                onMouseLeave={() => setHoveredItem(null)}
                style={{ justifyContent: 'space-between' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <item.icon size={20} style={{ 
                    color: activeSection === item.id || hoveredItem === item.id ? '#22d3ee' : '#94a3b8'
                  }} />
                  {!isCollapsed && <span>{item.label}</span>}
                </div>
                {!isCollapsed && (
                  expandedMenus[item.id] ? <ChevronUp size={16} color="#94a3b8" /> : <ChevronDown size={16} color="#94a3b8" />
                )}
              </div>
              
              {!isCollapsed && expandedMenus[item.id] && (
                <div className="submenu">
                  {item.subItems.map((subItem) => (
                    <Link 
                      key={subItem.id} 
                      to={subItem.path} 
                      className={`menu-item sub ${activeSection === subItem.id ? 'active' : ''}`}
                      onClick={() => setActiveSection(subItem.id)}
                      onMouseEnter={() => setHoveredItem(subItem.id)}
                      onMouseLeave={() => setHoveredItem(null)}
                    >
                      <subItem.icon size={16} style={{ 
                        color: activeSection === subItem.id || hoveredItem === subItem.id ? '#22d3ee' : '#94a3b8'
                      }} />
                      {subItem.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}

          <div className="admin-divider" />

          {singleItems.map((item) => (
            <Link 
              key={item.id}
              to={item.path} 
              className={`menu-item ${activeSection === item.id ? 'active' : ''}`}
              onClick={() => setActiveSection(item.id)}
              onMouseEnter={() => setHoveredItem(item.id)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              <item.icon size={20} style={{ 
                color: activeSection === item.id || hoveredItem === item.id ? '#22d3ee' : '#94a3b8'
              }} />
              {!isCollapsed && <span>{item.label}</span>}
            </Link>
          ))}
        </div>

        {/* Logout */}
        <div className="logout" onClick={handleLogout}>
          <div className="logout-item" style={{ cursor: "pointer" }}>
            <LogOut size={20} />
            {!isCollapsed && <span>Logout</span>}
          </div>
        </div>
      </aside>

      <main className="admin-content">
        <Routes>
          <Route path="/admin/home" element={<AdminHome />} />
        </Routes>
      </main>
    </div>
  );
}
