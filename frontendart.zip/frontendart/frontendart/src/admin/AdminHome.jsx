import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Palette, 
  Image, 
  TrendingUp,
  Eye,
  Heart,
  Star,
  Calendar,
  Activity,
  DollarSign,
  Award,
  Clock,
  UserPlus,
  ImagePlus,
  PlusCircle,
  BarChart3,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

export default function AdminHome() {
  const [isLoading, setIsLoading] = useState(true);
  const [hoveredCard, setHoveredCard] = useState(null);
  const [animatedNumbers, setAnimatedNumbers] = useState({
    users: 0,
    artists: 0,
    artworks: 0,
    revenue: 0
  });

  // Simulate loading and animate numbers
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 100);

    // Animate numbers counting up
    const animateNumber = (target, key, duration = 2000) => {
      const start = Date.now();
      const animate = () => {
        const elapsed = Date.now() - start;
        const progress = Math.min(elapsed / duration, 1);
        const current = Math.floor(target * progress);
        
        setAnimatedNumbers(prev => ({
          ...prev,
          [key]: current
        }));

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      animate();
    };

    setTimeout(() => {
      animateNumber(1247, 'users', 1500);
      animateNumber(89, 'artists', 1200);
      animateNumber(2341, 'artworks', 1800);
      animateNumber(45678, 'revenue', 2200);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const statsCards = [
    {
      id: 'users',
      title: 'Total Users',
      value: animatedNumbers.users.toLocaleString(),
      icon: Users,
      gradient: 'linear-gradient(135deg, #22d3ee, #06b6d4)',
      change: '+12%',
      isPositive: true,
      description: 'Active registered users'
    },
    {
      id: 'artists',
      title: 'Artists',
      value: animatedNumbers.artists.toLocaleString(),
      icon: Palette,
      gradient: 'linear-gradient(135deg, #a855f7, #8b5cf6)',
      change: '+8%',
      isPositive: true,
      description: 'Verified artists on platform'
    },
    {
      id: 'artworks',
      title: 'Artworks',
      value: animatedNumbers.artworks.toLocaleString(),
      icon: Image,
      gradient: 'linear-gradient(135deg, #ec4899, #f43f5e)',
      change: '+23%',
      isPositive: true,
      description: 'Total artworks uploaded'
    },
    {
      id: 'revenue',
      title: 'Revenue',
      value: `$${animatedNumbers.revenue.toLocaleString()}`,
      icon: DollarSign,
      gradient: 'linear-gradient(135deg, #10b981, #059669)',
      change: '+15%',
      isPositive: true,
      description: 'Monthly revenue generated'
    }
  ];

  const quickActions = [
    { id: 'add-user', title: 'Add New User', icon: UserPlus, color: '#22d3ee' },
    { id: 'add-artist', title: 'Add Artist', icon: PlusCircle, color: '#a855f7' },
    { id: 'add-artwork', title: 'Upload Artwork', icon: ImagePlus, color: '#ec4899' },
    { id: 'view-analytics', title: 'View Analytics', icon: BarChart3, color: '#10b981' }
  ];

  const recentActivities = [
    { id: 1, type: 'user', message: 'New user John Doe registered', time: '2 minutes ago', icon: Users },
    { id: 2, type: 'artwork', message: 'Artwork "Sunset Dreams" was uploaded', time: '15 minutes ago', icon: Image },
    { id: 3, type: 'artist', message: 'Artist profile verified: Sarah Johnson', time: '1 hour ago', icon: Palette },
    { id: 4, type: 'sale', message: 'Artwork sold for $1,250', time: '2 hours ago', icon: DollarSign },
    { id: 5, type: 'review', message: 'New 5-star review received', time: '3 hours ago', icon: Star }
  ];

  const StatCard = ({ card }) => {
    const isHovered = hoveredCard === card.id;
    
    return (
      <div
        style={{
          position: 'relative',
          background: 'linear-gradient(180deg, #1e293b, #0f172a)',
          borderRadius: '16px',
          padding: '24px',
          border: '1px solid rgba(51, 65, 85, 0.5)',
          cursor: 'pointer',
          transition: 'all 0.3s ease',
          transform: isHovered ? 'translateY(-8px) scale(1.02)' : 'translateY(0) scale(1)',
          boxShadow: isHovered 
            ? '0 25px 50px -12px rgba(0, 0, 0, 0.4), 0 0 30px rgba(34, 211, 238, 0.3)' 
            : '0 10px 25px -5px rgba(0, 0, 0, 0.2)'
        }}
        onMouseEnter={() => setHoveredCard(card.id)}
        onMouseLeave={() => setHoveredCard(null)}
      >
        {/* Animated background glow */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          borderRadius: '16px',
          background: isHovered ? card.gradient : 'transparent',
          opacity: isHovered ? 0.1 : 0,
          transition: 'all 0.5s ease'
        }} />

        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '12px',
              background: card.gradient,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 8px 25px -8px rgba(0, 0, 0, 0.3)',
              transform: isHovered ? 'rotate(10deg) scale(1.1)' : 'rotate(0deg) scale(1)',
              transition: 'all 0.3s ease'
            }}>
              <card.icon style={{ width: '24px', height: '24px', color: 'white' }} />
            </div>

            <div style={{ textAlign: 'right' }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
                color: card.isPositive ? '#10b981' : '#ef4444',
                fontSize: '14px',
                fontWeight: '600'
              }}>
                {card.isPositive ? (
                  <ArrowUp style={{ width: '16px', height: '16px' }} />
                ) : (
                  <ArrowDown style={{ width: '16px', height: '16px' }} />
                )}
                {card.change}
              </div>
            </div>
          </div>

          <div>
            <h3 style={{
              fontSize: '32px',
              fontWeight: 'bold',
              color: 'white',
              marginBottom: '4px',
              background: isHovered ? card.gradient : 'white',
              WebkitBackgroundClip: isHovered ? 'text' : 'unset',
              WebkitTextFillColor: isHovered ? 'transparent' : 'white',
              transition: 'all 0.3s ease'
            }}>
              {card.value}
            </h3>
            <p style={{ color: '#94a3b8', fontSize: '16px', fontWeight: '500', marginBottom: '8px' }}>
              {card.title}
            </p>
            <p style={{ color: '#64748b', fontSize: '14px' }}>
              {card.description}
            </p>
          </div>
        </div>
      </div>
    );
  };

  if (isLoading) {
    return (
      <div style={{
        marginLeft: '288px',
        minHeight: '100vh',
        background: 'linear-gradient(180deg, #0f172a, #1e293b, #0f172a)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          color: '#22d3ee'
        }}>
          <div style={{
            width: '32px',
            height: '32px',
            background: 'linear-gradient(135deg, #22d3ee, #a855f7)',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            animation: 'pulse 2s infinite'
          }}>
            <Activity style={{ width: '20px', height: '20px', color: 'white' }} />
          </div>
          <span style={{ fontSize: '18px', fontWeight: '600' }}>Loading Dashboard...</span>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      marginLeft: '288px',
      minHeight: '100vh',
      background: 'linear-gradient(180deg, #0f172a, #1e293b, #0f172a)',
      padding: '32px'
    }}>
      {/* Header */}
      <div style={{ marginBottom: '32px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
          <div>
            <h1 style={{
              fontSize: '32px',
              fontWeight: 'bold',
              background: 'linear-gradient(90deg, #22d3ee, #a855f7, #ec4899)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              marginBottom: '8px'
            }}>
              Admin Dashboard
            </h1>
            <p style={{ color: '#94a3b8', fontSize: '16px' }}>
              Welcome back! Here's what's happening with your art gallery.
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{
              background: 'linear-gradient(135deg, #1e293b, #0f172a)',
              border: '1px solid rgba(51, 65, 85, 0.5)',
              borderRadius: '12px',
              padding: '12px 16px',
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <Calendar style={{ width: '20px', height: '20px', color: '#22d3ee' }} />
              <span style={{ color: '#cbd5e1', fontSize: '14px', fontWeight: '500' }}>
                {new Date().toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '24px',
        marginBottom: '32px'
      }}>
        {statsCards.map((card) => (
          <StatCard key={card.id} card={card} />
        ))}
      </div>

      {/* Quick Actions & Recent Activity */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '32px',
        marginBottom: '32px'
      }}>
        {/* Quick Actions */}
        <div style={{
          background: 'linear-gradient(180deg, #1e293b, #0f172a)',
          borderRadius: '16px',
          padding: '24px',
          border: '1px solid rgba(51, 65, 85, 0.5)'
        }}>
          <h2 style={{
            fontSize: '20px',
            fontWeight: 'bold',
            color: 'white',
            marginBottom: '20px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <PlusCircle style={{ width: '24px', height: '24px', color: '#22d3ee' }} />
            Quick Actions
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            {quickActions.map((action) => (
              <div
                key={action.id}
                style={{
                  background: 'linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.8))',
                  border: '1px solid rgba(51, 65, 85, 0.3)',
                  borderRadius: '12px',
                  padding: '16px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  textAlign: 'center'
                }}
                onMouseEnter={(e) => {
                  e.target.style.transform = 'translateY(-4px)';
                  e.target.style.borderColor = `${action.color}50`;
                  e.target.style.boxShadow = `0 10px 25px -5px ${action.color}20`;
                }}
                onMouseLeave={(e) => {
                  e.target.style.transform = 'translateY(0)';
                  e.target.style.borderColor = 'rgba(51, 65, 85, 0.3)';
                  e.target.style.boxShadow = 'none';
                }}
              >
                <div style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '10px',
                  background: `${action.color}20`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 12px auto'
                }}>
                  <action.icon style={{ width: '20px', height: '20px', color: action.color }} />
                </div>
                <p style={{ color: '#cbd5e1', fontSize: '14px', fontWeight: '500' }}>
                  {action.title}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div style={{
          background: 'linear-gradient(180deg, #1e293b, #0f172a)',
          borderRadius: '16px',
          padding: '24px',
          border: '1px solid rgba(51, 65, 85, 0.5)'
        }}>
          <h2 style={{
            fontSize: '20px',
            fontWeight: 'bold',
            color: 'white',
            marginBottom: '20px',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <Activity style={{ width: '24px', height: '24px', color: '#22d3ee' }} />
            Recent Activity
          </h2>

          <div style={{ space: '12px' }}>
            {recentActivities.map((activity, index) => (
              <div
                key={activity.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px',
                  borderRadius: '8px',
                  marginBottom: index < recentActivities.length - 1 ? '8px' : '0',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.target.style.background = 'rgba(51, 65, 85, 0.3)';
                }}
                onMouseLeave={(e) => {
                  e.target.style.background = 'transparent';
                }}
              >
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  background: 'rgba(34, 211, 238, 0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  <activity.icon style={{ width: '16px', height: '16px', color: '#22d3ee' }} />
                </div>
                <div style={{ flex: 1 }}>
                  <p style={{ color: '#cbd5e1', fontSize: '14px', marginBottom: '2px' }}>
                    {activity.message}
                  </p>
                  <p style={{ color: '#64748b', fontSize: '12px' }}>
                    {activity.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Ambient glow effects */}
      <div style={{
        position: 'fixed',
        top: 0,
        left: '288px',
        right: 0,
        bottom: 0,
        pointerEvents: 'none',
        zIndex: -1
      }}>
        <div style={{
          position: 'absolute',
          top: '20%',
          right: '10%',
          width: '200px',
          height: '200px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(34, 211, 238, 0.1) 0%, transparent 70%)',
          animation: 'pulse 4s infinite'
        }} />
        <div style={{
          position: 'absolute',
          bottom: '20%',
          left: '20%',
          width: '150px',
          height: '150px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(168, 85, 247, 0.1) 0%, transparent 70%)',
          animation: 'pulse 4s infinite 2s'
        }} />
      </div>

      <style>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 1;
            transform: scale(1);
          }
          50% {
            opacity: 0.5;
            transform: scale(1.1);
          }
        }`}</style>
    </div>
  );
}