import React, { useState, useEffect } from "react";
import {
  Home, Palette, Heart, ShoppingCart, User, Search,
  Bell, Menu, X, ChevronDown, Filter, Grid, List,
  Star, Bookmark, Settings, LogOut, Eye, MessageCircle
} from "lucide-react";
import { Link, Routes, Route, useNavigate } from "react-router-dom";
import "./usernavbar.css";
import UserHome from "./UserHome";
import { useAuth } from "../contextapi/AuthContext";

export default function UserNavBar() {
  const { setIsAdminLoggedIn, setIsUserLoggedIn, setIsArtistLoggedIn } = useAuth();
  const navigate = useNavigate();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notificationCount, setNotificationCount] = useState(3);
  const [cartCount, setCartCount] = useState(5);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) setIsMobileMenuOpen(false);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.profile-dropdown-container')) {
        setIsProfileDropdownOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    setIsUserLoggedIn(false);
    setIsArtistLoggedIn(false);

    localStorage.setItem("isAdminLoggedIn", "false");
    localStorage.setItem("isUserLoggedIn", "false");
    localStorage.setItem("isArtistLoggedIn", "false");
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("username");

    navigate("/login");
  };

  const mainMenuItems = [
    { id: 'home', label: 'Home', icon: Home, path: '/user/home' },
    { id: 'gallery', label: 'Gallery', icon: Palette, path: '/user/gallery' },
    { id: 'artists', label: 'Artists', icon: Star, path: '/user/artists' },
    { id: 'favorites', label: 'Favorites', icon: Heart, path: '/user/favorites' }
  ];

  const profileMenuItems = [
    { id: 'profile', label: 'My Profile', icon: User, path: '/user/profile' },
    { id: 'orders', label: 'My Orders', icon: ShoppingCart, path: '/user/orders' },
    { id: 'watchlist', label: 'Watchlist', icon: Bookmark, path: '/user/watchlist' },
    { id: 'settings', label: 'Settings', icon: Settings, path: '/user/settings' }
  ];

  return (
    <div className="user-layout">
      <nav className="user-navbar">
        {/* Top Header */}
        <div className="navbar-header">
          <div className="navbar-container">
            {/* Logo */}
            <Link to="/user/home" className="navbar-logo" onClick={() => setActiveSection('home')}>
              <div className="logo-container">
                <div className="logo-icon">
                  <Palette size={24} />
                </div>
                <div className="logo-text">
                  <h2>ArtVault</h2>
                  <span>Gallery</span>
                </div>
              </div>
            </Link>

            {/* Search Bar - Desktop */}
            <div className="search-container desktop-only">
              <div className="search-wrapper">
                <Search size={20} className="search-icon" />
                <input
                  type="text"
                  placeholder="Search artworks, artists, or styles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                />
                <button className="search-filter-btn">
                  <Filter size={16} />
                </button>
              </div>
            </div>

            {/* Right Actions */}
            <div className="navbar-actions">
              {/* Notifications */}
              <div className="action-item notification-btn">
                <Bell size={20} />
                {notificationCount > 0 && (
                  <span className="badge">{notificationCount}</span>
                )}
              </div>

              {/* Cart */}
              <Link to="/user/cart" className="action-item cart-btn">
                <ShoppingCart size={20} />
                {cartCount > 0 && (
                  <span className="badge">{cartCount}</span>
                )}
              </Link>

              {/* Profile Dropdown */}
              <div className="profile-dropdown-container">
                <button
                  className="action-item profile-btn"
                  onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                >
                  <div className="profile-avatar">
                    <User size={18} />
                  </div>
                  <ChevronDown size={16} className={`dropdown-arrow ${isProfileDropdownOpen ? 'rotated' : ''}`} />
                </button>

                {isProfileDropdownOpen && (
                  <div className="profile-dropdown">
                    <div className="dropdown-header">
                      <div className="user-info">
                        <div className="user-avatar">JD</div>
                        <div>
                          <p className="user-name">John Doe</p>
                          <p className="user-email">john@example.com</p>
                        </div>
                      </div>
                    </div>
                    <div className="dropdown-divider" />
                    <div className="dropdown-menu">
                      {profileMenuItems.map((item) => (
                        <Link
                          key={item.id}
                          to={item.path}
                          className="dropdown-item"
                          onClick={() => {
                            setActiveSection(item.id);
                            setIsProfileDropdownOpen(false);
                          }}
                        >
                          <item.icon size={18} />
                          <span>{item.label}</span>
                        </Link>
                      ))}
                      <div className="dropdown-divider" />
                      <button className="dropdown-item logout-item" onClick={handleLogout}>
                        <LogOut size={18} />
                        <span>Logout</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Mobile Menu Toggle */}
              <button
                className="mobile-menu-toggle mobile-only"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Main Navigation */}
        <div className="navbar-main desktop-only">
          <div className="navbar-container">
            <div className="main-menu">
              {mainMenuItems.map((item) => (
                <Link
                  key={item.id}
                  to={item.path}
                  className={`menu-item ${activeSection === item.id ? 'active' : ''}`}
                  onClick={() => setActiveSection(item.id)}
                >
                  <item.icon size={18} />
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>

            {/* View Toggle */}
            <div className="view-toggle">
              <button className="view-btn active">
                <Grid size={16} />
              </button>
              <button className="view-btn">
                <List size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="mobile-menu">
            {/* Mobile Search */}
            <div className="mobile-search">
              <div className="search-wrapper">
                <Search size={20} className="search-icon" />
                <input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                />
              </div>
            </div>

            {/* Mobile Menu Items */}
            <div className="mobile-menu-items">
              {mainMenuItems.map((item) => (
                <Link
                  key={item.id}
                  to={item.path}
                  className={`mobile-menu-item ${activeSection === item.id ? 'active' : ''}`}
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <item.icon size={20} />
                  <span>{item.label}</span>
                </Link>
              ))}
              <div className="mobile-divider" />
              {profileMenuItems.map((item) => (
                <Link
                  key={item.id}
                  to={item.path}
                  className="mobile-menu-item"
                  onClick={() => {
                    setActiveSection(item.id);
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <item.icon size={20} />
                  <span>{item.label}</span>
                </Link>
              ))}
              <button className="mobile-menu-item logout-item" onClick={handleLogout}>
                <LogOut size={20} />
                <span>Logout</span>
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="user-content">
        <Routes>
          <Route path="/user/home" element={<UserHome />} />
        </Routes>
      </main>
    </div>
  );
}