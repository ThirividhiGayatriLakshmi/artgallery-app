import { createContext, useState, useContext, useEffect } from 'react';

// Create the context
const AuthContext = createContext();

// Provider component to manage login states and user data
export function AuthProvider({ children }) {
  // Load initial state from localStorage or default to false/null
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    return localStorage.getItem('isAdminLoggedIn') === 'true';
  });

  const [isUserLoggedIn, setIsUserLoggedIn] = useState(() => {
    return localStorage.getItem('isUserLoggedIn') === 'true';
  });
  
  const [isArtistLoggedIn, setIsArtistLoggedIn] = useState(() => {
    return localStorage.getItem('isArtistLoggedIn') === 'true';
  });

  // Save state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('isAdminLoggedIn', isAdminLoggedIn);
    localStorage.setItem('isUserLoggedIn', isUserLoggedIn);
    localStorage.setItem('isArtistLoggedIn', isArtistLoggedIn);
  }, [isAdminLoggedIn, isUserLoggedIn, isArtistLoggedIn]);

  return (
    <AuthContext.Provider
      value={{
        isAdminLoggedIn,
        setIsAdminLoggedIn,
        isUserLoggedIn,
        setIsUserLoggedIn,
        isArtistLoggedIn,
        setIsArtistLoggedIn,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// Custom hook to access the context
// eslint-disable-next-line react-refresh/only-export-components
export const useAuth = () => useContext(AuthContext);