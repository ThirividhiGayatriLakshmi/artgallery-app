import React, { useState } from "react";
import { FiSearch } from "react-icons/fi";
import { FaUserCircle } from "react-icons/fa";

const Messages = () => {
  const [searchQuery, setSearchQuery] = useState("");

  // Dummy conversation data
  const messages = [
    {
      id: 1,
      name: "John Doe",
      lastMessage: "Hi! I would like to know more about your artwork.",
      time: "2h ago",
    },
    {
      id: 2,
      name: "Emily Parker",
      lastMessage: "Thank you for the quick response!",
      time: "5h ago",
    },
    {
      id: 3,
      name: "Admin Support",
      lastMessage: "Your artwork has been approved.",
      time: "1d ago",
    },
  ];

  // Filter messages by user input
  const filteredMessages = messages.filter((msg) =>
    msg.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="px-10 py-8 w-full h-full">
      {/* ----------- Page Title ------------ */}
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">
        Messages
      </h2>

      {/* ----------- Search Bar ------------ */}
      <div className="flex items-center mb-6">
        <div className="relative w-80">
          <FiSearch className="absolute left-3 top-3 text-gray-500" size={18} />
          <input
            type="text"
            placeholder="Search messages..."
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-300 outline-none focus:border-purple-500 transition"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* ----------- Message List ------------ */}
      <div className="bg-white shadow-sm rounded-2xl border border-gray-200 p-4">
        {filteredMessages.length === 0 ? (
          <p className="text-gray-500 text-center py-6">
            No messages found.
          </p>
        ) : (
          filteredMessages.map((msg) => (
            <div
              key={msg.id}
              className="flex items-center gap-4 py-4 px-2 hover:bg-gray-50 cursor-pointer rounded-xl transition"
            >
              <FaUserCircle size={40} className="text-purple-500" />

              <div className="flex-1">
                <p className="font-semibold text-gray-700">{msg.name}</p>
                <p className="text-gray-500 text-sm">{msg.lastMessage}</p>
              </div>

              <span className="text-xs text-gray-400">{msg.time}</span>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Messages;
