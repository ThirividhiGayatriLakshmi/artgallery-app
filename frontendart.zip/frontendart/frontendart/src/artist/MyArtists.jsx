import React from "react";
import { FaUserCircle } from "react-icons/fa";

const MyArtists = () => {
  // Example data — replace with API later
  const artists = [
    {
      id: 1,
      name: "Aarav Sharma",
      role: "Digital Illustrator",
      followers: 2.1,
    },
    {
      id: 2,
      name: "Saanvi Reddy",
      role: "Watercolor Artist",
      followers: 3.4,
    },
    {
      id: 3,
      name: "Rohan Mehta",
      role: "3D Concept Designer",
      followers: 1.9,
    },
    {
      id: 4,
      name: "Meera Kapoor",
      role: "Portrait Artist",
      followers: 4.2,
    },
  ];

  return (
    <div className="px-10 py-8 w-full h-full">
      {/* ----------- Page Title ------------ */}
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">
        My Artists
      </h2>

      {/* ----------- Artist List Grid ------------ */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {artists.map((artist) => (
          <div
            key={artist.id}
            className="bg-white shadow-sm rounded-2xl border border-gray-200 p-5 hover:shadow-md transition cursor-pointer"
          >
            {/* Profile Icon */}
            <div className="flex justify-center mb-4">
              <FaUserCircle className="text-purple-500" size={60} />
            </div>

            {/* Artist Name */}
            <h3 className="text-lg font-semibold text-center text-gray-800">
              {artist.name}
            </h3>

            {/* Role */}
            <p className="text-sm text-center text-gray-500">
              {artist.role}
            </p>

            {/* Followers */}
            <p className="text-xs text-center text-gray-400 mt-1">
              {artist.followers}k followers
            </p>

            {/* Button */}
            <div className="flex justify-center mt-4">
              <button className="px-4 py-2 rounded-xl bg-purple-500 text-white text-sm hover:bg-purple-600 transition">
                View Profile
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyArtists;
