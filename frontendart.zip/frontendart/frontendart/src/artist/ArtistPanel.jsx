import React from 'react';
import { Routes, Route } from 'react-router-dom';

// Import the highly-styled NavBar component (Must be in the same folder or path adjusted)
import ArtistNavBar from './ArtistNavBar'; 

// --- Placeholder Content Components (You need to create these files) ---
import DashBoards from './DashBoards';        
import MyArtworks from './MyArtworks';      
import UploadArtwork from './UploadArtwork';  
import Orders from './Orders';              
import Earnings from './Earnings';          
import Messages from './Messages';          
import ArtistProfile from './ArtistProfile';  
import ArtistSettings from './ArtistSettings'; 

export default function ArtistPanel() {
  return (
    <div className="artist-layout"> 
      
      {/* 1. The Navigation Bar (The sticky header with all links) */}
      <ArtistNavBar />

      {/* 2. The Content Area: Renders the active route's component */}
      <main style={{ padding: '20px', flexGrow: 1, width: '95%', maxWidth: '1400px', margin: '0 auto' }}>
        <Routes>
          {/* Main Menu Routes (Paths must match those defined in ArtistNavBar) */}
          <Route path="/dashboard" element={<DashBoards />} />
          <Route path="/myart" element={<MyArtworks />} />
          <Route path="/upload" element={<UploadArtwork />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/earnings" element={<Earnings />} />
          <Route path="/messages" element={<Messages />} />
          
          {/* Profile Dropdown Routes */}
          <Route path="/profile" element={<ArtistProfile />} />
          <Route path="/settings" element={<ArtistSettings />} />
          
          {/* Default Index Route (i.e., when accessing /artist/ or /artist) */}
          <Route path="/" element={<DashBoards />} /> 
        </Routes>
      </main>
      
    </div>
  );
}