import React, { useEffect, useState } from "react";
import {
  FiDollarSign,
  FiTrendingUp,
  FiCalendar,
  FiCreditCard,
} from "react-icons/fi";

export default function Earnings() {
  const [fade, setFade] = useState(false);

  useEffect(() => {
    setTimeout(() => setFade(true), 100);
  }, []);

  const earningsData = [
    { month: "Jan", amount: 900 },
    { month: "Feb", amount: 1200 },
    { month: "Mar", amount: 700 },
    { month: "Apr", amount: 1500 },
    { month: "May", amount: 1100 },
    { month: "Jun", amount: 1700 },
  ];

  return (
    <div className={`earnings-page ${fade ? "fade-in" : ""}`}>
      {/* Header */}
      <div className="page-header">
        <h2>Earnings</h2>
        <p>Your monthly income, payouts & sales insights</p>
      </div>

      {/* Summary Cards */}
      <div className="earnings-summary">
        <div className="summary-card">
          <div className="summary-icon">
            <FiDollarSign />
          </div>
          <div>
            <h3>$4,650</h3>
            <p>Total Earnings</p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon">
            <FiTrendingUp />
          </div>
          <div>
            <h3>$1,720</h3>
            <p>This Month</p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon">
            <FiCalendar />
          </div>
          <div>
            <h3>12</h3>
            <p>Payouts</p>
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-icon">
            <FiCreditCard />
          </div>
          <div>
            <h3>$380</h3>
            <p>Pending</p>
          </div>
        </div>
      </div>

      {/* Earnings Graph */}
      <div className="earnings-chart">
        <h3 className="panel-title">Monthly Earnings</h3>

        <div className="chart-wrapper">
          {earningsData.map((d, i) => (
            <div key={i} className="chart-bar">
              <div
                className="bar"
                style={{ height: `${d.amount / 20}vh` }}
              ></div>
              <span className="chart-label">{d.month}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Payout History */}
      <div className="payout-section">
        <h3 className="panel-title">Payout History</h3>

        <table className="payout-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td>20 Jun 2025</td>
              <td>$450</td>
              <td className="paid">Paid</td>
            </tr>
            <tr>
              <td>11 Jun 2025</td>
              <td>$280</td>
              <td className="paid">Paid</td>
            </tr>
            <tr>
              <td>03 Jun 2025</td>
              <td>$380</td>
              <td className="pending">Pending</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
