import React from "react";

const Orders = () => {
  // Dummy order data — you can replace this with API data later
  const orders = [
    {
      id: "ORD-1001",
      artwork: "Nebula Echoes",
      buyer: "John Doe",
      price: "$1,250",
      status: "Completed",
    },
    {
      id: "ORD-1002",
      artwork: "Prismatic Pulse",
      buyer: "Emily Parker",
      price: "$980",
      status: "Pending",
    },
    {
      id: "ORD-1003",
      artwork: "Digital Dreams",
      buyer: "Aarav Sharma",
      price: "$1,600",
      status: "Cancelled",
    },
    {
      id: "ORD-1004",
      artwork: "Celestial Path",
      buyer: "Riya Mehta",
      price: "$2,050",
      status: "Completed",
    },
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-700";
      case "Pending":
        return "bg-yellow-100 text-yellow-700";
      case "Cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-200 text-gray-700";
    }
  };

  return (
    <div className="px-10 py-8 w-full h-full">
      {/* ----------- Page Title ------------ */}
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Orders</h2>

      {/* ----------- Orders Grid ------------ */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {orders.map((order) => (
          <div
            key={order.id}
            className="bg-white shadow-sm rounded-2xl border border-gray-200 p-6 hover:shadow-md transition"
          >
            {/* Order ID */}
            <div className="flex justify-between mb-3">
              <h3 className="text-lg font-semibold text-gray-800">
                {order.id}
              </h3>

              <span
                className={`px-3 py-1 text-xs rounded-full font-medium ${getStatusColor(
                  order.status
                )}`}
              >
                {order.status}
              </span>
            </div>

            {/* Artwork */}
            <p className="text-gray-600 text-sm mb-1">
              <b>Artwork:</b> {order.artwork}
            </p>

            {/* Buyer */}
            <p className="text-gray-600 text-sm mb-1">
              <b>Buyer:</b> {order.buyer}
            </p>

            {/* Price */}
            <p className="text-gray-600 text-sm mb-4">
              <b>Price:</b> {order.price}
            </p>

            {/* Button */}
            <button className="w-full mt-2 bg-purple-500 text-white py-2 rounded-xl text-sm hover:bg-purple-600 transition">
              View Details
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;
