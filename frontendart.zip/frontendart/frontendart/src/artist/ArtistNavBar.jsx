import React, { useState, useEffect } from "react";
import {
  Home,
  Palette,
  PlusCircle,
  Image,
  ShoppingCart,
  User,
  Search,
  Bell,
  Menu,
  X,
  ChevronDown,
  Filter,
  Grid,
  List,
  DollarSign,
  MessageCircle,
  Settings,
  LogOut,
} from "lucide-react";
import { Link, Routes, Route, useNavigate } from "react-router-dom";
import { useAuth } from "../contextapi/AuthContext";

export default function ArtistNavBar() {
  const { setIsAdminLoggedIn, setIsUserLoggedIn, setIsArtistLoggedIn } =
    useAuth();
  const navigate = useNavigate();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("dashboard");
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [notificationCount, setNotificationCount] = useState(2);

  // Handle Resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) setIsMobileMenuOpen(false);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Close profile dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest(".profile-dropdown-container")) {
        setIsProfileDropdownOpen(false);
      }
    };
    document.addEventListener("click", handleClickOutside);
    return () => document.removeEventListener("click", handleClickOutside);
  }, []);

  // Logout
  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    setIsUserLoggedIn(false);
    setIsArtistLoggedIn(false);

    localStorage.setItem("isAdminLoggedIn", "false");
    localStorage.setItem("isUserLoggedIn", "false");
    localStorage.setItem("isArtistLoggedIn", "false");
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("username");

    navigate("/login");
  };

  // Menu Items
  const mainMenuItems = [
    { id: "dashboard", label: "Dashboard", icon: Home, path: "/artist/dashboard" },
    { id: "myart", label: "My Artworks", icon: Image, path: "/artist/myart" },
    { id: "upload", label: "Upload Artwork", icon: PlusCircle, path: "/artist/upload" },
    { id: "orders", label: "Orders", icon: ShoppingCart, path: "/artist/orders" },
    { id: "earnings", label: "Earnings", icon: DollarSign, path: "/artist/earnings" },
    { id: "messages", label: "Messages", icon: MessageCircle, path: "/artist/messages" },
  ];

  const profileMenuItems = [
    { id: "profile", label: "My Profile", icon: User, path: "/artist/profile" },
    { id: "settings", label: "Settings", icon: Settings, path: "/artist/settings" },
  ];

  return (
    <>
      {/* -------------- CSS INCLUDED -------------- */}
      <style>{`
        .artist-layout{width:100%;min-height:100vh;background:#f8f9fc;display:flex;flex-direction:column}
        .artist-navbar{width:100%;background:#fff;border-bottom:1px solid#eef0f5;position:sticky;top:0;z-index:2000}
        .navbar-header{padding:12px 0;border-bottom:1px solid#f1f1f6}
        .navbar-container{width:95%;max-width:1400px;margin:auto;display:flex;justify-content:space-between;align-items:center}
        .navbar-logo{text-decoration:none}
        .logo-container{display:flex;align-items:center;gap:10px}
        .logo-icon{width:42px;height:42px;background:linear-gradient(135deg,#9a5fff,#6f75ff);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff}
        .logo-text h2{font-size:20px;font-weight:700;color:#5a2ff4;margin:0}
        .logo-text span{font-size:11px;color:#7a7899}
        .search-container{flex:1;max-width:420px}
        .search-wrapper{background:#fff;border:1px solid#e5e6f2;border-radius:50px;padding:8px 14px;display:flex;align-items:center;gap:10px}
        .search-input{border:none;outline:none;flex:1;font-size:15px;color:#444;background:transparent}
        .search-filter-btn{background:#6f75ff;border:none;padding:7px 10px;border-radius:10px;color:#fff;cursor:pointer}
        .search-filter-btn:hover{background:#574dff}
        .navbar-actions{display:flex;align-items:center;gap:18px}
        .action-item{position:relative;padding:8px;border-radius:10px;cursor:pointer;color:#5f5a8a;transition:.2s}
        .action-item:hover{background:#f2f1ff}
        .badge{position:absolute;top:-4px;right:-4px;background:#ff4d6d;color:#fff;padding:2px 6px;border-radius:50%;font-size:10px}
        .profile-btn{display:flex;align-items:center;gap:6px}
        .profile-avatar{width:36px;height:36px;background:#6f75ff;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center}
        .dropdown-arrow{transition:transform .2s}
        .dropdown-arrow.rotated{transform:rotate(180deg)}
        .profile-dropdown{position:absolute;right:0;top:50px;width:240px;background:#fff;border-radius:12px;border:1px solid#e6e6f2;
          box-shadow:0 8px 18px rgba(0,0,0,.08);padding:10px 0;animation:fadeIn .15s ease}
        @keyframes fadeIn{from{opacity:0;transform:translateY(-5px)}to{opacity:1;transform:translateY(0)}}
        .dropdown-header{padding:12px 18px;display:flex;align-items:center}
        .user-info{display:flex;gap:10px;align-items:center}
        .user-avatar{width:36px;height:36px;background:#7f63ff;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:bold}
        .user-name{margin:0;font-size:14px;font-weight:600}
        .user-email{margin:0;font-size:11px;color:#7c7b95}
        .dropdown-divider{height:1px;background:#f1f0fa;margin:6px 0}
        .dropdown-item{padding:10px 20px;display:flex;align-items:center;gap:12px;color:#4d4c6e;text-decoration:none;cursor:pointer;transition:.2s}
        .dropdown-item:hover{background:#f5f4ff}
        .logout-item{color:#ff4d6d}
        .navbar-main{width:100%;padding:14px 0}
        .main-menu{display:flex;align-items:center;gap:48px}
        .menu-item{display:flex;align-items:center;gap:10px;padding:6px 0;font-size:15px;color:#6c6a8c;font-weight:500;position:relative;text-decoration:none;transition:.2s}
        .menu-item:hover{color:#5b4eff}
        .menu-item.active{color:#5b4eff;font-weight:600}
        .menu-item.active::after{content:"";position:absolute;bottom:-6px;left:0;width:100%;height:3px;background:linear-gradient(to right,#6f75ff,#ff60d8);border-radius:50px}
        .desktop-only{display:block}
        .mobile-only{display:none}
        @media(max-width:768px){
          .desktop-only{display:none!important}
          .mobile-only{display:block}
          .mobile-menu{background:#fff;padding:10px;border-top:1px solid#eee}
          .mobile-menu-item{padding:14px;display:flex;align-items:center;gap:12px;border-bottom:1px solid#f5f5ff;font-size:16px}
        }
      `}</style>

      {/* ------------------ NAVBAR START ------------------ */}
      <div className="artist-layout">
        <nav className="artist-navbar">

          {/* Header */}
          <div className="navbar-header">
            <div className="navbar-container">

              {/* Logo */}
              <Link to="/artist/dashboard" className="navbar-logo">
                <div className="logo-container">
                  <div className="logo-icon"><Palette size={24} /></div>
                  <div className="logo-text">
                    <h2>ArtVault</h2>
                    <span>ARTIST PANEL</span>
                  </div>
                </div>
              </Link>

              {/* Search */}
              <div className="search-container desktop-only">
                <div className="search-wrapper">
                  <Search size={20} />
                  <input
                    type="text"
                    placeholder="Search artworks or orders..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="search-input"
                  />
                  <button className="search-filter-btn">
                    <Filter size={16} />
                  </button>
                </div>
              </div>

              {/* Actions */}
              <div className="navbar-actions">

                {/* Notifications */}
                <div className="action-item">
                  <Bell size={20} />
                  {notificationCount > 0 && (
                    <span className="badge">{notificationCount}</span>
                  )}
                </div>

                {/* Profile */}
                <div className="profile-dropdown-container">
                  <button
                    className="action-item profile-btn"
                    onClick={() =>
                      setIsProfileDropdownOpen(!isProfileDropdownOpen)
                    }
                  >
                    <div className="profile-avatar">
                      <User size={18} />
                    </div>

                    <ChevronDown
                      size={16}
                      className={`dropdown-arrow ${
                        isProfileDropdownOpen ? "rotated" : ""
                      }`}
                    />
                  </button>

                  {isProfileDropdownOpen && (
                    <div className="profile-dropdown">
                      <div className="dropdown-header">
                        <div className="user-info">
                          <div className="user-avatar">AR</div>
                          <div>
                            <p className="user-name">Artist Name</p>
                            <p className="user-email">artist@example.com</p>
                          </div>
                        </div>
                      </div>

                      <div className="dropdown-divider" />

                      <div className="dropdown-menu">
                        {profileMenuItems.map((item) => (
                          <Link key={item.id} to={item.path} className="dropdown-item">
                            <item.icon size={18} />
                            <span>{item.label}</span>
                          </Link>
                        ))}

                        <div className="dropdown-divider" />

                        {/* Logout */}
                        <button
                          className="dropdown-item logout-item"
                          onClick={handleLogout}
                        >
                          <LogOut size={18} />
                          <span>Logout</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Mobile Toggle */}
                <button
                  className="mobile-menu-toggle mobile-only"
                  onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                >
                  {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>

              </div>
            </div>
          </div>

          {/* Main Menu (Desktop) */}
          <div className="navbar-main desktop-only">
            <div className="navbar-container">
              <div className="main-menu">
                {mainMenuItems.map((item) => (
                  <Link
                    key={item.id}
                    to={item.path}
                    className={`menu-item ${activeSection === item.id ? "active" : ""}`}
                    onClick={() => setActiveSection(item.id)}
                  >
                    <item.icon size={18} />
                    <span>{item.label}</span>
                  </Link>
                ))}
              </div>

              <div className="view-toggle">
                <button className="view-btn active"><Grid size={16} /></button>
                <button className="view-btn"><List size={16} /></button>
              </div>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="mobile-menu">
              {mainMenuItems.map((item) => (
                <Link key={item.id} to={item.path} className="mobile-menu-item">
                  <item.icon size={20} />
                  <span>{item.label}</span>
                </Link>
              ))}

              <button className="mobile-menu-item logout-item" onClick={handleLogout}>
                <LogOut size={20} />
                <span>Logout</span>
              </button>
            </div>
          )}
        </nav>
      </div>
    </>
  );
}
