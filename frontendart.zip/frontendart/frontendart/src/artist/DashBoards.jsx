import React, { useEffect, useState } from "react";
import {
  FiBarChart2,
  FiShoppingBag,
  FiTrendingUp,
  FiHeart,
  FiUser,
} from "react-icons/fi";

export default function DashBoards() {
  const [fade, setFade] = useState(false);

  useEffect(() => {
    // Trigger the fade-in effect slightly after mount
    setTimeout(() => setFade(true), 100);
  }, []);

  return (
    <>
      {/* -------------------- INLINE CSS -------------------- */}
      <style>{`
        .artist-dashboard {
          opacity: 0;
          transition: opacity 0.5s ease-in-out;
          padding: 20px; 
          min-height: calc(100vh - 120px); /* Adjust height based on assumed navbar size */
        }
        .artist-dashboard.fade-in {
          opacity: 1;
        }

        /* Header */
        .dashboard-header {
          margin-bottom: 25px;
          padding: 0 0 10px 0;
        }
        .dashboard-header .title {
          font-size: 28px;
          font-weight: 700;
          color: #2b304c;
          margin: 0;
        }
        .dashboard-header .subtitle {
          font-size: 14px;
          color: #7a7899;
          margin: 5px 0 0 0;
        }

        /* Top Stats Container */
        .stats-container {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 20px;
          margin-bottom: 30px;
        }
        .stat-card {
          background: #ffffff;
          border-radius: 12px;
          padding: 20px;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.03);
          display: flex;
          align-items: center;
          gap: 15px;
          transition: transform 0.2s;
        }
        .stat-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 6px 15px rgba(0, 0, 0, 0.06);
        }
        .stat-card .icon-box {
          width: 50px;
          height: 50px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          color: #fff;
          font-size: 22px;
        }
        .stats-container .stat-card:nth-child(1) .icon-box {
          background-color: #5c62ff;
        } /* Artworks */
        .stats-container .stat-card:nth-child(2) .icon-box {
          background-color: #ff9a00;
        } /* Orders */
        .stats-container .stat-card:nth-child(3) .icon-box {
          background-color: #28a745;
        } /* Earnings */
        .stats-container .stat-card:nth-child(4) .icon-box {
          background-color: #ff4d6d;
        } /* Likes */
        .stat-card h3 {
          font-size: 24px;
          font-weight: 700;
          color: #2b304c;
          margin: 0;
        }
        .stat-card p {
          font-size: 13px;
          color: #7a7899;
          margin: 0;
        }

        /* Lower Grid & Panels */
        .bottom-grid {
          display: grid;
          grid-template-columns: 1fr 1fr 2fr; /* Default layout for full-panel usage */
          gap: 20px;
        }
        .panel {
          background: #ffffff;
          border-radius: 12px;
          padding: 25px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
        }
        .panel-title {
          font-size: 18px;
          font-weight: 600;
          color: #2b304c;
          margin: 0 0 15px 0;
          padding-bottom: 10px;
          border-bottom: 1px solid #f1f1f6;
        }

        /* Recent Activity */
        .activity-list {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        .activity-list li {
          padding: 10px 0;
          font-size: 14px;
          color: #4d4c6e;
          border-bottom: 1px dashed #f1f1f6;
        }
        .activity-list li:last-child {
          border-bottom: none;
        }
        .activity-list b {
          color: #5c62ff;
          font-weight: 600;
        }

        /* Profile Status */
        .profile-box {
          text-align: center;
          padding: 15px 0 20px 0;
        }
        .profile-icon {
          font-size: 40px;
          color: #6f75ff;
          margin-bottom: 10px;
          border: 2px solid #6f75ff;
          border-radius: 50%;
          padding: 8px;
        }
        .profile-box p {
          font-size: 14px;
          color: #4d4c6e;
          margin: 0;
        }
        .complete-btn {
          width: 100%;
          padding: 10px;
          background-color: #5c62ff;
          color: #fff;
          border: none;
          border-radius: 8px;
          font-weight: 600;
          cursor: pointer;
          transition: background-color 0.2s;
          margin-top: 10px;
        }
        .complete-btn:hover {
          background-color: #4348e0;
        }

        /* Engagement Summary */
        .full-panel {
          grid-column: span 2; /* Span two columns in the lower grid */
        }
        .engage-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 15px;
          padding-top: 10px;
        }
        .engage-box {
          text-align: center;
          padding: 15px 10px;
          border: 1px solid #f1f1f6;
          border-radius: 10px;
          transition: background 0.2s;
        }
        .engage-box:hover {
          background: #f8f9ff;
          border-color: #d8dbf0;
        }
        .engage-icon {
          font-size: 28px;
          color: #5c62ff;
          margin-bottom: 5px;
        }
        .engage-box h3 {
          font-size: 20px;
          font-weight: 700;
          color: #2b304c;
          margin: 5px 0 0 0;
        }
        .engage-box p {
          font-size: 12px;
          color: #7a7899;
          margin: 0;
        }

        /* Responsiveness */
        @media (max-width: 1024px) {
          .stats-container {
            grid-template-columns: repeat(2, 1fr);
          }
          .bottom-grid {
            grid-template-columns: 1fr 1fr;
          }
          .full-panel {
            grid-column: span 2;
          }
          .engage-grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }
        @media (max-width: 600px) {
          .stats-container {
            grid-template-columns: 1fr;
          }
          .bottom-grid {
            grid-template-columns: 1fr;
          }
          .full-panel {
            grid-column: span 1;
          }
          .engage-grid {
            grid-template-columns: repeat(2, 1fr); /* Keep 2 columns for smaller grid */
          }
          .dashboard-header .title {
            font-size: 24px;
          }
          .stat-card {
            padding: 15px;
          }
        }
      `}</style>
      {/* --------------------------------------------------------- */}

      <div className={`artist-dashboard ${fade ? "fade-in" : ""}`}>
        {/* Page Heading */}
        <div className="dashboard-header">
          <h2 className="title">Dashboard</h2>
          <p className="subtitle">Overview of your activity & analytics</p>
        </div>

        {/* Top Stats */}
        <div className="stats-container">
          <div className="stat-card">
            <div className="icon-box">
              <FiBarChart2 />
            </div>
            <div>
              <h3>24</h3>
              <p>Total Artworks</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="icon-box">
              <FiShoppingBag />
            </div>
            <div>
              <h3>18</h3>
              <p>Orders</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="icon-box">
              <FiTrendingUp />
            </div>
            <div>
              <h3>$12,450</h3>
              <p>Earnings</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="icon-box">
              <FiHeart />
            </div>
            <div>
              <h3>340</h3>
              <p>Total Likes</p>
            </div>
          </div>
        </div>

        {/* Lower Grid */}
        <div className="bottom-grid">
          {/* Recent Activity */}
          <div className="panel">
            <h3 className="panel-title">Recent Activity</h3>

            <ul className="activity-list">
              <li>🖼️ You uploaded <b>“Cosmic Pulse”</b></li>
              <li>💸 New order for <b>“Digital Bloom”</b></li>
              <li>❤️ <b>12 new likes</b> today</li>
              <li>💬 New message from a buyer</li>
            </ul>
          </div>

          {/* Profile Completion */}
          <div className="panel">
            <h3 className="panel-title">Profile Status</h3>

            <div className="profile-box">
              <FiUser className="profile-icon" />
              <p>Your profile is 90% complete</p>
            </div>

            <button className="complete-btn">Complete Profile</button>
          </div>

          {/* Engagement Summary */}
          <div className="panel full-panel">
            <h3 className="panel-title">Engagement Summary</h3>

            <div className="engage-grid">
              <div className="engage-box">
                <FiTrendingUp className="engage-icon" />
                <h3>4.8k</h3>
                <p>Reach</p>
              </div>

              <div className="engage-box">
                <FiHeart className="engage-icon" />
                <h3>112</h3>
                <p>Likes (Monthly)</p>
              </div>

              <div className="engage-box">
                <FiShoppingBag className="engage-icon" />
                <h3>42</h3>
                <p>Sales</p>
              </div>

              <div className="engage-box">
                <FiBarChart2 className="engage-icon" />
                <h3>12%</h3>
                <p>Growth</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}