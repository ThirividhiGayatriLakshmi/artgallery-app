import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";

const UploadArtWork = () => {
  const [preview, setPreview] = useState(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "",
    price: "",
    image: null,
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleImage = (e) => {
    const file = e.target.files[0];
    setFormData({ ...formData, image: file });

    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Uploaded Artwork:", formData);
    alert("Artwork uploaded successfully!");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="p-6"
    >
      <h2 className="text-3xl font-semibold mb-6">Upload Artwork</h2>

      <Card className="shadow-md rounded-2xl">
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-5">

            {/* Image Upload */}
            <div>
              <label className="block mb-2 text-sm font-medium">Upload Image</label>
              <Input type="file" accept="image/*" onChange={handleImage} />

              {preview && (
                <img
                  src={preview}
                  alt="Preview"
                  className="mt-4 h-48 w-48 object-cover rounded-xl shadow"
                />
              )}
            </div>

            {/* Title */}
            <div>
              <label className="block mb-1 text-sm font-medium">Artwork Title</label>
              <Input
                name="title"
                value={formData.title}
                placeholder="Enter Artwork Title"
                onChange={handleChange}
              />
            </div>

            {/* Description */}
            <div>
              <label className="block mb-1 text-sm font-medium">Description</label>
              <Textarea
                name="description"
                value={formData.description}
                placeholder="Enter Description"
                onChange={handleChange}
              />
            </div>

            {/* Category */}
            <div>
              <label className="block mb-1 text-sm font-medium">Category</label>
              <Input
                name="category"
                value={formData.category}
                placeholder="e.g., Painting, Sketch, Digital Art"
                onChange={handleChange}
              />
            </div>

            {/* Price */}
            <div>
              <label className="block mb-1 text-sm font-medium">Price (₹)</label>
              <Input
                type="number"
                name="price"
                value={formData.price}
                placeholder="Enter Price"
                onChange={handleChange}
              />
            </div>

            {/* Submit */}
            <Button type="submit" className="w-full py-2 text-lg">
              Upload Artwork
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default UploadArtWork;
