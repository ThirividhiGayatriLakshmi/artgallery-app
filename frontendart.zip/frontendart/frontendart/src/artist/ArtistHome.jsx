import React, { useEffect, useState } from "react";

export default function ArtistHome() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 100);
  }, []);

  const artistArtworks = [
    {
      id: 1,
      title: "Nebula Echoes",
      price: "$1,850",
      image:
        "https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=500&h=400&fit=crop",
      stats: "340 Views • 28 Likes",
      badge: "Top Rated",
    },
    {
      id: 2,
      title: "Shattered Reality",
      price: "$2,150",
      image:
        "https://images.unsplash.com/photo-1487700160041-babef9c3cb55?w=500&h=400&fit=crop",
      stats: "220 Views • 14 Likes",
      badge: "New",
    },
    {
      id: 3,
      title: "Glitched Horizon",
      price: "$1,480",
      image:
        "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500&h=400&fit=crop",
      stats: "410 Views • 39 Likes",
    },
    {
      id: 4,
      title: "Prismatic Pulse",
      price: "$2,600",
      image:
        "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?w=500&h=400&fit=crop",
      stats: "305 Views • 19 Likes",
      soldOut: true,
    },
  ];

  return (
    <div className="home-container">
      {/* HERO SECTION */}
      <section className="page-header hero-section">
        <h1 className={`hero-title ${isVisible ? "fade-in" : ""}`}>
          Welcome Back, Artist!
        </h1>
        <p className="hero-subtitle">
          Manage your artworks, track your performance, and showcase your talent
          to art lovers across the world.
        </p>
        <div className="hero-cta">
          <a href="#myart" className="btn btn-primary">
            View My Artworks
          </a>
          &nbsp;&nbsp;
          <a href="/artist/upload" className="btn btn-secondary">
            Upload New Artwork
          </a>
        </div>
      </section>

      {/* DASHBOARD STATS */}
      <section className="main-content">
        <div className="dashboard-stats">
          <div className="stat-card">
            <h2>24</h2>
            <p>Total Artworks</p>
          </div>

          <div className="stat-card">
            <h2>$12,450</h2>
            <p>Total Earnings</p>
          </div>

          <div className="stat-card">
            <h2>18</h2>
            <p>Orders Received</p>
          </div>

          <div className="stat-card">
            <h2>5</h2>
            <p>New Messages</p>
          </div>
        </div>
      </section>

      {/* ARTWORKS SECTION */}
      <section id="myart" className="main-content">
        <div className="page-header">
          <h1>My Artworks</h1>
          <p>Your uploaded artworks and their performance overview</p>
        </div>

        <div className="gallery-grid">
          {artistArtworks.map((art) => (
            <div
              key={art.id}
              className={`artwork-card ${
                art.soldOut ? "sold-out" : ""
              } ${art.badge ? "featured" : ""}`}
            >
              <div className="card-image">
                <img src={art.image} alt={art.title} />

                {art.badge && (
                  <div
                    className={`badge ${
                      art.badge === "New" ? "badge-new" : ""
                    }`}
                  >
                    {art.badge}
                  </div>
                )}
              </div>

              <div className="card-content">
                <h3 className="artwork-title">{art.title}</h3>
                <p className="artist-name">{art.stats}</p>
                <div className="artwork-price">{art.price}</div>

                {/* Actions */}
                <div className="card-actions">
                  {!art.soldOut ? (
                    <>
                      <button className="btn btn-primary">Edit</button>
                      <button className="btn btn-secondary">View</button>
                    </>
                  ) : (
                    <button className="btn btn-secondary" disabled>
                      Sold Out
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-4">
          <a href="/artist/myart" className="btn btn-primary">
            Manage All Artworks
          </a>
        </div>
      </section>

      {/* FEATURED COLLECTIONS */}
      <section className="main-content artists-section">
        <div className="page-header">
          <h1>Featured Collections</h1>
          <p>Create and organize your artworks into beautiful themed collections</p>
        </div>

        <div className="gallery-grid">
          {[
            {
              name: "Futuristic Vibes",
              count: 8,
              image:
                "https://images.unsplash.com/photo-1497366216548-37526070297c?w=500&h=400&fit=crop",
            },
            {
              name: "Urban Echoes",
              count: 5,
              image:
                "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=500&h=400&fit=crop",
            },
            {
              name: "Digital Dreams",
              count: 12,
              image:
                "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=500&h=400&fit=crop",
            },
          ].map((col, i) => (
            <div key={i} className="artwork-card">
              <div className="card-image" style={{ height: "220px" }}>
                <img src={col.image} alt={col.name} />
              </div>
              <div className="card-content text-center">
                <h3 className="artwork-title">{col.name}</h3>
                <p className="artist-name">{col.count} Artworks</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* NEWSLETTER / UPDATE SECTION */}
      <section className="main-content newsletter-section text-center">
        <div className="page-header">
          <h1>Get Updates</h1>
          <p>Stay notified about new features, analytics, and buyer activity</p>
        </div>

        <form className="newsletter-form">
          <input
            type="email"
            placeholder="Enter your email"
            className="newsletter-input"
          />
          <button className="btn btn-primary">Subscribe</button>
        </form>
      </section>
    </div>
  );
}
