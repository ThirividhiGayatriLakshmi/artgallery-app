import React, { useState } from 'react';
import axios from 'axios';

export default function Register() {
  const [entity, setEntity] = useState('user');
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    email: '',
    contact: '',
    address: '',
    imageUrl: '',
    bio: ''
  });

  const [toast, setToast] = useState({ message: '', type: '' });

  const handleEntityChange = (e) => {
    setEntity(e.target.value);
    setToast({ message: '', type: '' });
    setFormData({
      name: '',
      username: '',
      email: '',
      contact: '',
      address: '',
      imageUrl: '',
      bio: ''
    });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const showToast = (message, type) => {
    setToast({ message, type });
    setTimeout(() => {
      setToast({ message: '', type: '' });
    }, 4000);
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  try {
    let url = '';
    let payload = {};

    if (entity === 'user') {
      url = 'http://localhost:2027/userapi/register';
      payload = {
        name: formData.name,
        username: formData.username,
        email: formData.email,
        contact: formData.contact,
        address: formData.address,
        imageUrl: formData.imageUrl
      };
    } else if (entity === 'artist') {
      url = 'http://localhost:2027/artistapi/register';
      payload = {
        name: formData.name,
        bio: formData.bio,
        email: formData.email,
        username: formData.username,
        contact: formData.contact,
        imageUrl: formData.imageUrl
      };
    }

    const response = await axios.post(url, payload);

    if (response.status === 200) {
      setFormData({
        name: '',
        username: '',
        email: '',
        contact: '',
        address: '',
        imageUrl: '',
        bio: ''
      });
      showToast("Registration successful!", "success");
    }
  } catch (error) {
    const backendMessage =
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.response?.data ||
      "Error occurred";

    showToast(backendMessage, "error");
  }
};


  return (
    <div className="main-content">
      {/* Toast Notification */}
      {toast.message && (
        <div className={`toast ${toast.type}`}>
          {toast.message}
        </div>
      )}

      <div className="page-header">
        <h1>{entity === 'user' ? 'User Registration' : 'Artist Registration'}</h1>
        <p>Please fill in the details below to register as a {entity}</p>
      </div>

      <div className="text-center mb-3">
        <label><b>Select Entity: </b></label>
        <select value={entity} onChange={handleEntityChange}>
          <option value="user">User</option>
          <option value="artist">Artist</option>
        </select>
      </div>

      <form onSubmit={handleSubmit} className="form-container">
        <div className="mb-2">
          <label>Name</label>
          <input type="text" id="name" value={formData.name} onChange={handleChange} required />
        </div>

        <div className="mb-2">
          <label>Username</label>
          <input type="text" id="username" value={formData.username} onChange={handleChange} required />
        </div>

        <div className="mb-2">
          <label>Email</label>
          <input type="email" id="email" value={formData.email} onChange={handleChange} required />
        </div>

        {/* Contact field common for both */}
        <div className="mb-2">
          <label>Contact</label>
          <input type="text" id="contact" value={formData.contact} onChange={handleChange} required />
        </div>

        {entity === 'user' && (
          <div className="mb-2">
            <label>Address</label>
            <input type="text" id="address" value={formData.address} onChange={handleChange} />
          </div>
        )}

        {entity === 'artist' && (
          <div className="mb-2">
            <label>Bio</label>
            <textarea id="bio" value={formData.bio} onChange={handleChange} rows="3" />
          </div>
        )}

        <div className="mb-2">
          <label>Image URL</label>
          <input type="url" id="imageUrl" value={formData.imageUrl} onChange={handleChange} />
        </div>

        <div className="text-center mt-3">
          <button type="submit" className="btn btn-primary">Register</button>
        </div>
      </form>
    </div>
  );
}
