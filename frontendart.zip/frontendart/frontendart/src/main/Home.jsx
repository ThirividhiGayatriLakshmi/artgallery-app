import React, { useEffect, useState } from 'react';

export default function Home() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 100);
  }, []);

  const featuredArtworks = [
    {
      id: 1,
      title: "Digital Dreams",
      artist: "Alexandra Chen",
      price: "$2,850",
      image: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=500&h=400&fit=crop",
      description: "A mesmerizing digital composition exploring the boundaries between reality and imagination.",
      dimensions: "24\" x 36\" • Digital Art",
      featured: true,
      badge: "Featured"
    },
    {
      id: 2,
      title: "Neon Cityscapes",
      artist: "Marcus Rodriguez",
      price: "$3,200",
      image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=500&h=400&fit=crop",
      description: "Vibrant urban landscapes painted with electric energy and futuristic vision.",
      dimensions: "30\" x 40\" • Acrylic on Canvas",
      badge: "New"
    },
    {
      id: 3,
      title: "Cosmic Harmony",
      artist: "Luna Nakamura",
      price: "$1,950",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=500&h=400&fit=crop",
      description: "An ethereal journey through space and time, capturing the universe's infinite beauty.",
      dimensions: "20\" x 30\" • Mixed Media"
    },
    {
      id: 4,
      title: "Abstract Emotions",
      artist: "David Kim",
      price: "$2,400",
      image: "https://images.unsplash.com/photo-1549289524-06cf8837ace5?w=500&h=400&fit=crop",
      description: "Bold strokes and vibrant colors expressing the depth of human emotions.",
      dimensions: "28\" x 35\" • Oil on Canvas"
    },
    {
      id: 5,
      title: "Future Botanica",
      artist: "Sofia Petrov",
      price: "$3,750",
      image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=500&h=400&fit=crop",
      description: "Imagining how nature might evolve in a technologically advanced future.",
      dimensions: "32\" x 48\" • Digital Mixed Media",
      featured: true
    },
    {
      id: 6,
      title: "Quantum Reflections",
      artist: "James Wright",
      price: "$2,100",
      image: "https://images.unsplash.com/photo-1551913902-c92207136625?w=500&h=400&fit=crop",
      description: "Exploring quantum physics through abstract visual interpretations.",
      dimensions: "22\" x 28\" • Watercolor & Digital",
      soldOut: true
    }
  ];

  return (
    <div className="home-container">
      {/* Hero Section */}
      <section className="page-header hero-section">
        <h1 className={`hero-title ${isVisible ? 'fade-in' : ''}`}>
          Future Art Gallery
        </h1>
        <p className="hero-subtitle">
          Discover extraordinary digital and contemporary artworks from visionary artists around the world. 
          Experience art in a whole new dimension with our immersive, futuristic gallery space.
        </p>
        <div className="hero-cta">
          <a href="#gallery" className="btn btn-primary">Explore Gallery</a>&nbsp;&nbsp;
          <a href="#collections" className="btn btn-secondary">View Collections</a>
        </div>
      </section>

      {/* Featured Gallery Section */}
      <section id="gallery" className="main-content">
        <div className="page-header">
          <h1>Featured Artworks</h1>
          <p>Handpicked masterpieces from our most talented contemporary artists</p>
        </div>

        <div className="gallery-grid">
          {featuredArtworks.map((artwork) => (
            <div 
              key={artwork.id} 
              className={`artwork-card ${artwork.featured ? 'featured' : ''} ${artwork.soldOut ? 'sold-out' : ''}`}
            >
              {/* Card Image */}
              <div className="card-image">
                <img 
                  src={artwork.image} 
                  alt={artwork.title}
                  loading="lazy"
                />
                {artwork.badge && (
                  <div className={`badge ${artwork.badge === 'New' ? 'badge-new' : ''}`}>
                    {artwork.badge}
                  </div>
                )}
              </div>

              {/* Card Content */}
              <div className="card-content">
                <h3 className="artwork-title">{artwork.title}</h3>
                <p className="artist-name">by {artwork.artist}</p>
                <div className="artwork-price">{artwork.price}</div>

                {/* Card Actions */}
                <div className="card-actions">
                  {!artwork.soldOut ? (
                    <>
                      <button className="btn btn-primary">Add to Cart</button>
                      <button className="btn btn-secondary">View Details</button>
                    </>
                  ) : (
                    <button className="btn btn-secondary" disabled>Sold Out</button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-4">
          <button className="btn btn-primary">View All Artworks</button>
        </div>
      </section>

      {/* Artists Spotlight Section */}
      <section className="main-content artists-section">
        <div className="page-header">
          <h1>Featured Artists</h1>
          <p>Meet the visionary creators behind these extraordinary works</p>
        </div>

        <div className="gallery-grid">
          {[
            {
              name: "Alexandra Chen",
              specialty: "Digital Art",
              image: "https://images.unsplash.com/photo-1494790108755-2616b612b043?w=300&h=300&fit=crop&crop=face",
              artworks: 24
            },
            {
              name: "Marcus Rodriguez",
              specialty: "Contemporary Painting",
              image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop&crop=face",
              artworks: 18
            },
            {
              name: "Luna Nakamura",
              specialty: "Mixed Media",
              image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=300&h=300&fit=crop&crop=face",
              artworks: 31
            }
          ].map((artist, index) => (
            <div key={index} className="artwork-card">
              <div className="card-image" style={{ height: "220px" }}>
                <img src={artist.image} alt={artist.name} />
              </div>
              <div className="card-content text-center">
                <h3 className="artwork-title">{artist.name}</h3>
                <p className="artist-name">{artist.specialty}</p>
                <p className="artwork-price">{artist.artworks} Artworks</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="main-content newsletter-section text-center">
        <div className="page-header">
          <h1>Stay Connected</h1>
          <p>Get notified about new artworks, exclusive collections, and special events</p>
        </div>

        <form className="newsletter-form">
          <input 
            type="email" 
            placeholder="Enter your email"
            className="newsletter-input"
          />
          <button className="btn btn-primary">Subscribe</button>
        </form>
      </section>
    </div>
  );
}
