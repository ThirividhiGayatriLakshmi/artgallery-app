import React from 'react';

export default function About() {
  return (
    <div className="about-page" style={{ padding: '40px', fontFamily: 'Arial, sans-serif', lineHeight: '1.6' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>About Our Online Art Gallery</h1>

      <p>
        Welcome to our Online Art Gallery! We are dedicated to connecting talented artists with art enthusiasts
        around the world. Our platform provides a seamless experience for discovering, exploring, and purchasing
        beautiful artworks from diverse artists.
      </p>

      <h2 style={{ marginTop: '30px' }}>Our Mission</h2>
      <p>
        Our mission is to make art accessible to everyone and to provide a platform for artists to showcase their
        talent globally. We believe in promoting creativity, culture, and artistic expression.
      </p>

      <h2 style={{ marginTop: '30px' }}>What We Offer</h2>
      <ul>
        <li>Curated collections of original artworks from emerging and established artists.</li>
        <li>Secure and easy online purchase and delivery of artworks.</li>
        <li>Detailed artist profiles and artwork descriptions.</li>
        <li>Regular updates on art exhibitions, events, and special collections.</li>
      </ul>

      <h2 style={{ marginTop: '30px' }}>Join Us</h2>
      <p>
        Whether you are an artist wanting to showcase your work or a collector looking for your next masterpiece,
        our gallery provides the perfect platform. Explore, connect, and experience the world of art like never before!
      </p>
    </div>
  );
}
