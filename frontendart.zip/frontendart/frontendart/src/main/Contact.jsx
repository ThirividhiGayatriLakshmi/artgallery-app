import React, { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [status, setStatus] = useState('');

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Here you can integrate backend API to send the message
    console.log(formData);
    setStatus('Message sent successfully!');
    setFormData({ name: '', email: '', message: '' });
  };

  return (
    <div className="contact-page" style={{ padding: '40px', fontFamily: 'Arial, sans-serif', lineHeight: '1.6' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>Contact Us</h1>

      <p style={{ textAlign: 'center' }}>
        Have questions or want to reach out? Fill out the form below or use the contact information provided.
      </p>

      <div style={{ maxWidth: '600px', margin: '0 auto' }}>
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <input
            type="text"
            name="name"
            placeholder="Your Name"
            value={formData.name}
            onChange={handleChange}
            required
            style={{ padding: '10px', fontSize: '16px' }}
          />
          <input
            type="email"
            name="email"
            placeholder="Your Email"
            value={formData.email}
            onChange={handleChange}
            required
            style={{ padding: '10px', fontSize: '16px' }}
          />
          <textarea
            name="message"
            placeholder="Your Message"
            value={formData.message}
            onChange={handleChange}
            required
            rows="5"
            style={{ padding: '10px', fontSize: '16px' }}
          />
          <button type="submit" style={{ padding: '12px', fontSize: '16px', backgroundColor: '#007bff', color: '#fff', border: 'none', cursor: 'pointer' }}>
            Send Message
          </button>
        </form>

        {status && <p style={{ marginTop: '15px', color: 'green', textAlign: 'center' }}>{status}</p>}
      </div>

      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <h3>Other Ways to Reach Us</h3>
        <p>Email: kritika@onlineartgallery.com</p>
        <p>Phone: +91 9963861228</p>
        <p>Address: kvr petrol bunk,nellore, India</p>
      </div>
    </div>
  );
}
