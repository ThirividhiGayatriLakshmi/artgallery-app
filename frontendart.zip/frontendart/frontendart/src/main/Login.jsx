import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contextapi/AuthContext";

export default function Login() {
  const [formData, setFormData] = useState({
    identifier: "",
    password: ""
  });
  const [toast, setToast] = useState({ message: "", type: "" });
  const navigate = useNavigate();

  const { setIsAdminLoggedIn, setIsUserLoggedIn, setIsArtistLoggedIn } = useAuth();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.id]: e.target.value });
  };

  const showToast = (message, type) => {
    setToast({ message, type });
    setTimeout(() => setToast({ message: "", type: "" }), 4000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:2027/auth/checkapi/checklogin",
        formData
      );

      if (response.status === 200) {
        const { token, role, data } = response.data;
        const username = data.username || data.identifier;

        localStorage.setItem("token", token);
        localStorage.setItem("role", role);
        localStorage.setItem("username", username);

        if (role === "admin") {
          setIsAdminLoggedIn(true);
          setIsUserLoggedIn(false);
          setIsArtistLoggedIn(false);
          localStorage.setItem("isAdminLoggedIn", "true");
          localStorage.setItem("isUserLoggedIn", "false");
          localStorage.setItem("isArtistLoggedIn", "false");
          navigate("/admin/home");
        } 
        else if (role === "user") {
          setIsUserLoggedIn(true);
          setIsAdminLoggedIn(false);
          setIsArtistLoggedIn(false);
          localStorage.setItem("isUserLoggedIn", "true");
          localStorage.setItem("isAdminLoggedIn", "false");
          localStorage.setItem("isArtistLoggedIn", "false");
          navigate("/user/home");
        } 
        else if (role === "artist") {
          setIsArtistLoggedIn(true);
          setIsAdminLoggedIn(false);
          setIsUserLoggedIn(false);
          localStorage.setItem("isArtistLoggedIn", "true");
          localStorage.setItem("isAdminLoggedIn", "false");
          localStorage.setItem("isUserLoggedIn", "false");
          navigate("/artist/home");
        }
        showToast("Login successful!", "success");
      }
    } catch (error) {
      const backendMessage =
        error.response?.data?.message ||
        error.response?.data?.error ||
        error.response?.data ||
        "Invalid username or password";

      showToast(backendMessage, "error");
    }
  };

  const handleForgotPassword = () => {
    navigate("/forgot-password");
  };

  return (
    <div className="auth-page">
      {toast.message && <div className={`toast ${toast.type}`}>{toast.message}</div>}

      <div className="auth-box">
        <div className="page-header">
          <h1>Login</h1>
          <p>Enter your credentials to access your account</p>
        </div>

        <form onSubmit={handleSubmit} className="form-container" align="center">
          <div className="mb-2">
            <label>Username: </label>
            <input
              type="text"
              id="identifier"
              value={formData.identifier}
              onChange={handleChange}
              required
            />
          </div>

          <div className="mb-2">
            <label>Password: </label>
            <input
              type="password"
              id="password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>

          <div className="text-center mt-3">
            <button type="submit" className="btn btn-primary">Login</button>
          </div>

          <div className="text-center mt-2">
            <button type="button" className="forgot-password-link" onClick={handleForgotPassword}>Forgot Password?</button>
          </div>
        </form>
      </div>
    </div>
  );
}
