package com.klef.dev.service;

import com.klef.dev.entity.Order;
import com.klef.dev.entity.User;
import com.klef.dev.entity.Cart;
import java.util.List;

public interface OrderService {
    Order createOrder(User user, Cart cart);
    Order getOrderById(int id);
    List<Order> getOrdersByUser(User user);
    void deleteOrderById(int id);
}
