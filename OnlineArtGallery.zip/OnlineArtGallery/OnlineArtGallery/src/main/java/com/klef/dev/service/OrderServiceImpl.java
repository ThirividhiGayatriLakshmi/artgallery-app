package com.klef.dev.service;

import com.klef.dev.entity.Order;
import com.klef.dev.entity.OrderItem;
import com.klef.dev.entity.User;
import com.klef.dev.entity.Cart;
import com.klef.dev.entity.CartItem;
import com.klef.dev.repository.OrderRepository;
import com.klef.dev.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private OrderItemRepository orderItemRepository;
    @Autowired
    private CartService cartService;

    @Override
    public Order createOrder(User user, Cart cart) {
        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(new Date());
        order.setStatus("Pending");

        double totalAmount = 0.0;
        if (cart.getCartItems() != null) {
            for (CartItem cartItem : cart.getCartItems()) {
                OrderItem orderItem = new OrderItem();
                orderItem.setOrder(order);
                orderItem.setArtwork(cartItem.getArtwork());
                orderItem.setPriceAtPurchase(cartItem.getArtwork().getPrice());
                orderItemRepository.save(orderItem);
                totalAmount += orderItem.getPriceAtPurchase();
            }
        }
        order.setTotalAmount(totalAmount);
        orderRepository.save(order);
        cartService.clearCart(user);
        return order;
    }

    @Override
    public Order getOrderById(int id) {
        Optional<Order> orderOptional = orderRepository.findById(id);
        return orderOptional.orElse(null);
    }

    @Override
    public List<Order> getOrdersByUser(User user) {
        return orderRepository.findByUser(user);
    }

    @Override
    public void deleteOrderById(int id) {
        orderRepository.deleteById(id);
    }
}
