package com.klef.dev.service;

import com.klef.dev.entity.Order;
import com.klef.dev.entity.Payment;

public interface PaymentService {
    Payment processPayment(Order order, String paymentMethod, double amount);
    Payment getPaymentByOrderId(int orderId);
}
