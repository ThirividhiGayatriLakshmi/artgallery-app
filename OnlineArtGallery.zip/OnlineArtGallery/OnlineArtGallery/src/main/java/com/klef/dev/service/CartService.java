package com.klef.dev.service;

import com.klef.dev.entity.Cart;
import com.klef.dev.entity.Artwork;
import com.klef.dev.entity.User;

public interface CartService {
    Cart getCartByUser(User user);
    Cart addArtworkToCart(User user, Artwork artwork);
    void removeArtworkFromCart(User user, Artwork artwork);
    void clearCart(User user);
}
