package com.klef.dev.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "artwork_table")
public class Artwork {
	@Id
	@Column(name = "artwork_id")
	private int id;
	@Column(name = "artwork_title", nullable = false, length = 100)
	private String title;
	@Column(name = "artwork_description", nullable = true, length = 1000)
	private String description;
	@Column(name = "artwork_price", nullable = false)
	private double price;
	@Column(name = "artwork_image_url", nullable = false, length = 255)
	private String imageUrl;

	// This establishes a many-to-one relationship with the Artist entity.
	// Many Artworks can belong to one Artist.
	@ManyToOne
	@JoinColumn(name = "artist_id", nullable = false)
	private Artist artist;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public Artist getArtist() {
		return artist;
	}

	public void setArtist(Artist artist) {
		this.artist = artist;
	}

	@Override
	public String toString() {
		return "Artwork [id=" + id + ", title=" + title + ", description=" + description + ", price=" + price
				+ ", imageUrl=" + imageUrl + "]";
	}
}
