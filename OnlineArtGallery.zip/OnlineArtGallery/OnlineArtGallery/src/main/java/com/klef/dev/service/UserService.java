package com.klef.dev.service;

import java.util.List;
import java.util.Optional;

import com.klef.dev.entity.User;

public interface UserService {
    User registerUser(User user);
    User checkuserlogin(String username, String password);
    User getUserById(int id);
    List<User> getAllUsers();
    User updateUser(User user);
    void deleteUserById(int id);
    Optional<User> findByEmail(String email);
    User findUserByUsername(String username);
    
    public String generateResetToken(String email);
	public boolean validateResetToken(String token);
	public boolean changePassword(User user, String oldPassword, String newPassword);
	public void updatePassword(String token, String newPassword);
	public void deleteResetToken(String token);
	public boolean isTokenExpired(String token);
}