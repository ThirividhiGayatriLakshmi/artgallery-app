package com.klef.dev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineArtGalleryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineArtGalleryApplication.class, args);
		System.out.println("Online Art Gallery System backend is running successfully.");
	}

}
