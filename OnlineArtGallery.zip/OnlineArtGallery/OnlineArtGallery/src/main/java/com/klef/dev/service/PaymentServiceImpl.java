package com.klef.dev.service;

import com.klef.dev.entity.Order;
import com.klef.dev.entity.Payment;
import com.klef.dev.repository.OrderRepository;
import com.klef.dev.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.Date;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Payment processPayment(Order order, String paymentMethod, double amount) {
        // Here you would integrate with a third-party payment gateway (e.g., Stripe, PayPal).
        // For now, we'll just simulate a successful payment.

        // Create a new Payment entity
        Payment payment = new Payment();
        payment.setAmount(amount);
        payment.setPaymentMethod(paymentMethod);
        payment.setTransactionId("TXN_" + System.currentTimeMillis()); // Simulate a unique transaction ID
        payment.setPaymentDate(new Date());

        // Update the order status to "Payment Received" and link the payment
        order.setStatus("Payment Received");
        order.setPayment(payment);

        // Save both the payment and the updated order
        paymentRepository.save(payment);
        orderRepository.save(order);

        return payment;
    }

    @Override
    public Payment getPaymentByOrderId(int orderId) {
        // Find the order by ID
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isPresent()) {
            // If the order is found, return its associated payment
            return optionalOrder.get().getPayment();
        }
        return null;
    }
}
