package com.klef.dev.controller;

import com.klef.dev.dto.OrderRequestDTO;
import com.klef.dev.entity.Order;
import com.klef.dev.entity.User;
import com.klef.dev.entity.Cart;
import com.klef.dev.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orderapi/")
@CrossOrigin(origins = "*")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Create Order
    @PostMapping("/create")
    public ResponseEntity<Order> createOrder(@RequestBody OrderRequestDTO orderRequest) {
        User user = new User();
        user.setId(orderRequest.getUserId());

        Cart cart = new Cart();
        cart.setId(orderRequest.getCartId());

        Order newOrder = orderService.createOrder(user, cart);
        return new ResponseEntity<>(newOrder, HttpStatus.CREATED);
    }

    // Get Order by ID
    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable int id) {
        Order order = orderService.getOrderById(id);
        if (order != null) {
            return new ResponseEntity<>(order, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Get Orders by User
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> getOrdersByUser(@PathVariable int userId) {
        User user = new User();
        user.setId(userId);

        List<Order> orders = orderService.getOrdersByUser(user);
        return new ResponseEntity<>(orders, HttpStatus.OK);
    }

    // Delete Order by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteOrderById(@PathVariable int id) {
        orderService.deleteOrderById(id);
        return new ResponseEntity<>("Order deleted successfully", HttpStatus.OK);
    }
}
