package com.klef.dev.service;

import com.klef.dev.entity.Admin;
import com.klef.dev.entity.Artwork;
import com.klef.dev.entity.Artist;
import com.klef.dev.entity.User;
import java.util.List;

public interface AdminService {
    Admin checkadminlogin(String username, String password);

    // User management
    List<User> getAllUsers();
    User getUserById(int id);
    void deleteUserById(int id);

    // Artist management
    List<Artist> getAllArtists();
    Artist getArtistById(int id);
    void deleteArtistById(int id);

    // Artwork management
    List<Artwork> getAllArtworks();
    Artwork getArtworkById(int id);
    void deleteArtworkById(int id);
}
