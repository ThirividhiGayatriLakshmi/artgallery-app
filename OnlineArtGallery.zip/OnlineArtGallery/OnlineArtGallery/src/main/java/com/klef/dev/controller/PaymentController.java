package com.klef.dev.controller;

import com.klef.dev.dto.PaymentDTO;
import com.klef.dev.entity.Payment;
import com.klef.dev.entity.Order;
import com.klef.dev.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/paymentapi/")
@CrossOrigin(origins = "*")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // Process Payment
    @PostMapping("/process")
    public ResponseEntity<Payment> processPayment(@RequestBody PaymentDTO paymentDTO) {
        Order order = new Order();
        order.setId(paymentDTO.getOrderId());

        Payment payment = paymentService.processPayment(order,
                paymentDTO.getPaymentMethod(),
                paymentDTO.getAmount());

        return new ResponseEntity<>(payment, HttpStatus.CREATED);
    }

    // Get Payment by Order ID
    @GetMapping("/order/{orderId}")
    public ResponseEntity<Payment> getPaymentByOrderId(@PathVariable int orderId) {
        Payment payment = paymentService.getPaymentByOrderId(orderId);
        if (payment != null) {
            return new ResponseEntity<>(payment, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
