package com.klef.dev.service;

import com.klef.dev.entity.Artwork;
import com.klef.dev.repository.ArtworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ArtworkServiceImpl implements ArtworkService {

    @Autowired
    private ArtworkRepository artworkRepository;

    @Override
    public Artwork addArtwork(Artwork artwork) {
        return artworkRepository.save(artwork);
    }
    
    @Override
    public List<Artwork> getAllArtworks() {
        return artworkRepository.findAll();
    }
    
    @Override
    public Artwork getArtworkById(int id) {
        Optional<Artwork> artworkOptional = artworkRepository.findById(id);
        return artworkOptional.orElse(null);
    }
    
    @Override
    public Artwork updateArtwork(Artwork artwork) {
        return artworkRepository.save(artwork);
    }
    
    @Override
    public void deleteArtworkById(int id) {
        artworkRepository.deleteById(id);
    }
}
