package com.klef.dev.controller;

import com.klef.dev.entity.Artwork;
import com.klef.dev.entity.Artist;
import com.klef.dev.entity.User;
import com.klef.dev.service.AdminService;
import com.klef.dev.security.JWTUtilizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/adminapi")
@CrossOrigin("*")
public class AdminController {

    @Autowired
    private AdminService adminService;
    @Autowired
    private JWTUtilizer jwtService;
    
    private boolean isAdmin(String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return false;
        String token = authHeader.substring(7);
        return "ADMIN".equals(jwtService.validateToken(token).get("role"));
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> viewAllUsers(@RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body(null);
        return ResponseEntity.ok(adminService.getAllUsers());
    }
    
	/*
	 * @GetMapping("/users") public ResponseEntity<?>
	 * viewAllUsers(@RequestHeader(value = "Authorization", required = false) String
	 * authHeader) { if (authHeader == null || !authHeader.startsWith("Bearer ")) {
	 * return ResponseEntity.status(HttpStatus.FORBIDDEN).
	 * body("Access Denied! Token missing"); }
	 * 
	 * String token = authHeader.substring(7); if
	 * (!jwtService.validateToken(token).get("role").equals("ADMIN")) { return
	 * ResponseEntity.status(HttpStatus.FORBIDDEN).
	 * body("Access Denied! Admin privileges required"); }
	 * 
	 * return ResponseEntity.ok(adminService.getAllUsers()); }
	 */


    @GetMapping("/users/{id}")
    public ResponseEntity<User> viewUserById(@PathVariable int id,
                                             @RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body(null);

        User user = adminService.getUserById(id);
        return (user != null) ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<String> deleteUserById(@PathVariable int id,
                                                 @RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body("Access Denied! Admin privileges required");

        adminService.deleteUserById(id);
        return ResponseEntity.ok("User with ID " + id + " deleted successfully.");
    }

    @GetMapping("/artists")
    public ResponseEntity<List<Artist>> viewAllArtists(@RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body(null);

        return ResponseEntity.ok(adminService.getAllArtists());
    }

    @GetMapping("/artists/{id}")
    public ResponseEntity<Artist> viewArtistById(@PathVariable int id,
                                                 @RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body(null);

        Artist artist = adminService.getArtistById(id);
        return (artist != null) ? ResponseEntity.ok(artist) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/artists/{id}")
    public ResponseEntity<String> deleteArtistById(@PathVariable int id,
                                                   @RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body("Access Denied! Admin privileges required");

        adminService.deleteArtistById(id);
        return ResponseEntity.ok("Artist with ID " + id + " deleted successfully.");
    }
    
    @GetMapping("/artworks")
    public ResponseEntity<List<Artwork>> viewAllArtworks(@RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body(null);

        return ResponseEntity.ok(adminService.getAllArtworks());
    }

    @GetMapping("/artworks/{id}")
    public ResponseEntity<Artwork> viewArtworkById(@PathVariable int id,
                                                   @RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body(null);

        Artwork artwork = adminService.getArtworkById(id);
        return (artwork != null) ? ResponseEntity.ok(artwork) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/artworks/{id}")
    public ResponseEntity<String> deleteArtworkById(@PathVariable int id,
                                                    @RequestHeader("Authorization") String authHeader) {
        if (!isAdmin(authHeader)) return ResponseEntity.status(403).body("Access Denied! Admin privileges required");

        adminService.deleteArtworkById(id);
        return ResponseEntity.ok("Artwork with ID " + id + " deleted successfully.");
    }
}
