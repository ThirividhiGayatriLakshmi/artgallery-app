package com.klef.dev.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.klef.dev.entity.Artist;

@Repository
public interface ArtistRepository extends JpaRepository<Artist, Integer> {

	public Artist findByUsernameAndPassword(String username, String password);
	
	public Artist findByUsername(String username);
	
	public Optional<Artist> findByEmail(String email);
}
