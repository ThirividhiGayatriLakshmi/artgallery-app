package com.klef.dev.service;

import com.klef.dev.entity.Cart;
import com.klef.dev.entity.CartItem;
import com.klef.dev.entity.Artwork;
import com.klef.dev.entity.User;
import com.klef.dev.repository.CartRepository;
import com.klef.dev.repository.CartItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private CartItemRepository cartItemRepository;

    @Override
    public Cart getCartByUser(User user) {
        Optional<Cart> cartOptional = cartRepository.findByUser(user);
        return cartOptional.orElseGet(() -> {
            Cart newCart = new Cart();
            newCart.setUser(user);
            return cartRepository.save(newCart);
        });
    }

    @Override
    public Cart addArtworkToCart(User user, Artwork artwork) {
        Cart cart = getCartByUser(user);
        CartItem cartItem = new CartItem();
        cartItem.setCart(cart);
        cartItem.setArtwork(artwork);
        cartItemRepository.save(cartItem);
        return cart;
    }

    @Override
    public void removeArtworkFromCart(User user, Artwork artwork) {
        Cart cart = getCartByUser(user);
        Optional<CartItem> cartItemOptional = cartItemRepository.findByCartAndArtwork(cart, artwork);
        cartItemOptional.ifPresent(item -> cartItemRepository.delete(item));
    }

    @Override
    public void clearCart(User user) {
        Cart cart = getCartByUser(user);
        cartItemRepository.deleteByCart(cart);
    }
}