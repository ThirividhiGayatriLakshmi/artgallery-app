package com.klef.dev.service;

import com.klef.dev.entity.Artwork;
import java.util.List;

public interface ArtworkService {
    Artwork addArtwork(Artwork artwork);
    List<Artwork> getAllArtworks();
    Artwork getArtworkById(int id);
    Artwork updateArtwork(Artwork artwork);
    void deleteArtworkById(int id);
}
