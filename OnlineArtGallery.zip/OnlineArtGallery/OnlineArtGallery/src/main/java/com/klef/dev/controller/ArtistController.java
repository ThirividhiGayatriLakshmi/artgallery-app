package com.klef.dev.controller;

import com.klef.dev.entity.Artist;
import com.klef.dev.entity.Artwork;
import com.klef.dev.service.ArtistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/artistapi/")
@CrossOrigin(origins = "*")
public class ArtistController {

    @Autowired
    private ArtistService artistService;

    @PostMapping("/register")
    public ResponseEntity<Artist> registerArtist(@RequestBody Artist artist) {
        Artist newArtist = artistService.registerArtist(artist);
        return new ResponseEntity<>(newArtist, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Artist> getArtistById(@PathVariable int id) {
        Artist artist = artistService.getArtistById(id);
        if (artist != null) {
            return new ResponseEntity<>(artist, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @PutMapping("/update")
    public ResponseEntity<Artist> updateArtist(@RequestBody Artist artist) {
        Artist updatedArtist = artistService.updateArtist(artist);
        return new ResponseEntity<>(updatedArtist, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteArtistById(@PathVariable int id) {
        artistService.deleteArtistById(id);
        return new ResponseEntity<>("Artist deleted successfully", HttpStatus.OK);
    }

    // --- Artwork Management Endpoints for Artist ---
    
    @PostMapping("/artwork/add")
    public ResponseEntity<Artwork> addArtwork(@RequestBody Artwork artwork) {
        Artwork newArtwork = artistService.addArtwork(artwork);
        return new ResponseEntity<>(newArtwork, HttpStatus.CREATED);
    }
    
    @GetMapping("/artwork/{id}")
    public ResponseEntity<Artwork> getArtworkById(@PathVariable int id) {
        Artwork artwork = artistService.getArtworkById(id);
        if (artwork != null) {
            return new ResponseEntity<>(artwork, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/artworks/all/{artistId}")
    public ResponseEntity<List<Artwork>> getArtworksByArtistId(@PathVariable int artistId) {
        List<Artwork> artworks = artistService.getArtworksByArtistId(artistId);
        return new ResponseEntity<>(artworks, HttpStatus.OK);
    }
    
    @DeleteMapping("/artwork/delete/{id}")
    public ResponseEntity<String> deleteArtworkById(@PathVariable int id) {
        artistService.deleteArtworkById(id);
        return new ResponseEntity<>("Artwork deleted successfully", HttpStatus.OK);
    }
}
