package com.klef.dev.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.klef.dev.dto.LoginRequest;
import com.klef.dev.entity.Admin;
import com.klef.dev.entity.Artist;
import com.klef.dev.entity.User;
import com.klef.dev.security.JWTUtilizer;
import com.klef.dev.service.AdminService;
import com.klef.dev.service.ArtistService;
import com.klef.dev.service.UserService;


@RestController
@RequestMapping("/auth/checkapi/")
@CrossOrigin("*")
public class LoginController {
	
	@Autowired
	private AdminService adminService;
	@Autowired	
	private ArtistService artistService;
	@Autowired
	private UserService userService;
	@Autowired
	private JWTUtilizer jwtService;
	
	@GetMapping("/")
	public String home() {
		return "Online Art Gallery Backend Project is Running";
	}
	
	@PostMapping("/checklogin")
	public ResponseEntity<?> login(@RequestBody LoginRequest loginrequest) {
		
		String identifier = loginrequest.getIdentifier();
		String password = loginrequest.getPassword();
		
		Admin admin = adminService.checkadminlogin(identifier, password);
		Artist artist = artistService.checkartistlogin(identifier, password);
		User user = userService.checkuserlogin(identifier, password);
		
		if(admin != null) {
			String token = jwtService.generateJWTToken(admin.getUsername(), "ADMIN");
			Map<String, Object> res = new HashMap<String, Object>();
			res.put("role", "admin");
			res.put("message", "Login Successful");
			res.put("token", token);
			res.put("data", admin);
			
			return ResponseEntity.ok(res);
		}
		if(artist != null) {
			String token = jwtService.generateJWTToken(artist.getUsername(), "ARTIST");
			Map<String, Object> res = new HashMap<String, Object>();
			res.put("role", "artist");
			res.put("message", "Login Successful");
			res.put("token", token);
			res.put("data", artist);

			return ResponseEntity.ok(res);
		}
		if(user != null) {
				String token = jwtService.generateJWTToken(user.getUsername(), "USER");
				Map<String, Object> res = new HashMap<String, Object>();
				res.put("role", "user");
				res.put("message", "Login Successful");
				res.put("token", token);
				res.put("data", user);

				return ResponseEntity.ok(res);
		}
		return ResponseEntity.status(401).body(Map.of("message", "Invalid Username/Email or Password"));
	}
	
    @PostMapping("/forgotpassword")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");

        Optional<Artist> artist= artistService.findByEmail(email);
        if (artist != null) {
            String token = artistService.generateResetToken(email);
            return ResponseEntity.ok(Map.of("message", "Reset link sent", "token", token));
        }

        Optional<User> user = userService.findByEmail(email);
        if (user != null) {
            String token = userService.generateResetToken(email);
            return ResponseEntity.ok(Map.of("message", "Reset link sent", "token", token));
        }

        return ResponseEntity.status(404).body(Map.of("message", "Email not found"));
    }

    @GetMapping("/isresetlinkexpired")
    public ResponseEntity<?> isResetLinkExpired(@RequestParam String token) {
        boolean isValidManager = artistService.validateResetToken(token) && !artistService.isTokenExpired(token);
        boolean isValidEmployee = userService.validateResetToken(token) && !userService.isTokenExpired(token);

        if (isValidManager || isValidEmployee) {
            return ResponseEntity.ok(Map.of("valid", true));
        } else {
            return ResponseEntity.status(400).body(Map.of("valid", false, "message", "Link expired or invalid"));
        }
    }

    @PostMapping("/resetpassword")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        String token = request.get("token");
        String newPassword = request.get("newpassword");

        if (artistService.validateResetToken(token)) {
            if (artistService.isTokenExpired(token)) {
                return ResponseEntity.status(400).body(Map.of("message", "Token expired"));
            }
            artistService.updatePassword(token, newPassword);
            artistService.deleteResetToken(token);
            return ResponseEntity.ok(Map.of("message", "Password updated for Manager"));
        }

        if (userService.validateResetToken(token)) {
            if (userService.isTokenExpired(token)) {
                return ResponseEntity.status(400).body(Map.of("message", "Token expired"));
            }
            userService.updatePassword(token, newPassword);
            userService.deleteResetToken(token);
            return ResponseEntity.ok(Map.of("message", "Password updated for Employee"));
        }

        return ResponseEntity.status(400).body(Map.of("message", "Invalid or expired token"));
    }

    @PostMapping("/changepassword")
    public ResponseEntity<?> changePassword(@RequestBody Map<String, String> request) {
        String role = request.get("role");
        String username = request.get("username");
        String oldPassword = request.get("oldpassword");
        String newPassword = request.get("newpassword");

        if (role.equalsIgnoreCase("ARTIST")) {
            Artist manager = artistService.findArtistByUsername(username);
            if (manager != null && artistService.changePassword(manager, oldPassword, newPassword)) {
                return ResponseEntity.ok(Map.of("message", "Password changed for Manager"));
            } else {
                return ResponseEntity.status(400).body(Map.of("message", "Old password incorrect"));
            }
        }
        else if (role.equalsIgnoreCase("USER")) {
            User user= userService.findUserByUsername(username);
            if (user != null && userService.changePassword(user, oldPassword, newPassword)) {
                return ResponseEntity.ok(Map.of("message", "Password changed for Employee"));
            } 
            else {
                return ResponseEntity.status(400).body(Map.of("message", "Old password incorrect"));
            }
        } 
        else {
            return ResponseEntity.status(403).body(Map.of("message", "Admins can't change password here"));
        }
    }
}