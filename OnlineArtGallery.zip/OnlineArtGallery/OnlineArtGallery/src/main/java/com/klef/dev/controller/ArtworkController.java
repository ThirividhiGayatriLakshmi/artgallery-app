package com.klef.dev.controller;

import com.klef.dev.entity.Artwork;
import com.klef.dev.service.ArtworkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/artworkapi/")
@CrossOrigin(origins = "*")
public class ArtworkController {

    @Autowired
    private ArtworkService artworkService;

    @PostMapping("/add")
    public ResponseEntity<Artwork> addArtwork(@RequestBody Artwork artwork) {
        Artwork newArtwork = artworkService.addArtwork(artwork);
        return new ResponseEntity<>(newArtwork, HttpStatus.CREATED);
    }

    // Get All Artworks
    @GetMapping("/all")
    public ResponseEntity<List<Artwork>> getAllArtworks() {
        List<Artwork> artworks = artworkService.getAllArtworks();
        return new ResponseEntity<>(artworks, HttpStatus.OK);
    }

    // Get Artwork by ID
    @GetMapping("/{id}")
    public ResponseEntity<Artwork> getArtworkById(@PathVariable int id) {
        Artwork artwork = artworkService.getArtworkById(id);
        if (artwork != null) {
            return new ResponseEntity<>(artwork, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    // Update Artwork
    @PutMapping("/update")
    public ResponseEntity<Artwork> updateArtwork(@RequestBody Artwork artwork) {
        Artwork updatedArtwork = artworkService.updateArtwork(artwork);
        return new ResponseEntity<>(updatedArtwork, HttpStatus.OK);
    }

    // Delete Artwork by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteArtworkById(@PathVariable int id) {
        artworkService.deleteArtworkById(id);
        return new ResponseEntity<>("Artwork deleted successfully", HttpStatus.OK);
    }
}
