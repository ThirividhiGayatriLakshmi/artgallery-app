package com.klef.dev.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.util.List;

@Entity
@Table(name = "artist_table")
public class Artist {
	@Id
	@Column(name = "artist_id")
	private int id;
	@Column(name = "artist_name", nullable = false, length = 100)
	private String name;
	@Column(name = "artist_bio", nullable = true, length = 500)
	private String bio;
	@Column(name = "artist_email", nullable = false, unique = true, length = 50)
	private String email;
	@Column(name="artist_username",nullable = false,unique=true,length = 50)
	private String username;
	@Column(name = "artist_password", nullable = false, length = 100)
	private String password;
	@Column(name = "artist_contact", nullable = false, unique = true, length = 20)
	private String contact;
	@Column(name = "artist_image_url", nullable = true, length = 255)
	private String imageUrl;
	@Column(nullable = false)
	private String role;

	// This establishes a one-to-many relationship with the Artwork entity.
	// An Artist can have many Artworks.
	@OneToMany(mappedBy = "artist", cascade = CascadeType.ALL)
	private List<Artwork> artworks;
	
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public List<Artwork> getArtworks() {
		return artworks;
	}

	public void setArtworks(List<Artwork> artworks) {
		this.artworks = artworks;
	}

	@Override
	public String toString() {
		return "Artist [id=" + id + ", name=" + name + ", bio=" + bio + ", email=" + email + ", password=" + password
				+ ", contact=" + contact + ", imageUrl=" + imageUrl + "]";
	}
}
