package com.klef.dev.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "payment_table")
public class Payment {
	@Id
	@Column(name = "payment_id")
	private int id;
	@Column(name = "payment_date", nullable = false)
	private Date paymentDate;
	@Column(name = "amount", nullable = false)
	private double amount;
	@Column(name = "payment_method", nullable = false, length = 50)
	private String paymentMethod; // e.g., "Credit Card", "PayPal"
	@Column(name = "transaction_id", nullable = false, length = 100, unique = true)
	private String transactionId;
	@Column(name = "status", nullable = false, length = 20)
	private String status; // e.g., "Successful", "Failed"

	// A one-to-one relationship with the Order entity
	@OneToOne(mappedBy = "payment")
	private Order order;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "Payment [id=" + id + ", amount=" + amount + ", paymentMethod=" + paymentMethod + ", status=" + status
				+ "]";
	}
}
