package com.klef.dev.service;

import com.klef.dev.entity.Artist;
import com.klef.dev.entity.Artwork;
import java.util.List;
import java.util.Optional;

public interface ArtistService {
    Artist registerArtist(Artist artist);
    Artist checkartistlogin(String username, String password);
    Artist getArtistById(int id);
    Artist updateArtist(Artist artist);
    void deleteArtistById(int id);
    Optional<Artist> findByEmail(String email);
    Artist findArtistByUsername(String username);
    
    // Artwork management by the artist
    Artwork addArtwork(Artwork artwork);
    Artwork getArtworkById(int id);
    List<Artwork> getArtworksByArtistId(int artistId);
    void deleteArtworkById(int id);
    
    public String generateResetToken(String email);
	public boolean validateResetToken(String token);
	public boolean changePassword(Artist artist, String oldPassword, String newPassword);
	public void updatePassword(String token, String newPassword);
	public void deleteResetToken(String token);
	public boolean isTokenExpired(String token);
	
}
