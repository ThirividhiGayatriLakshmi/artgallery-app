package com.klef.dev.service;

import com.klef.dev.entity.ResetToken;
import com.klef.dev.entity.User;
import com.klef.dev.repository.ResetTokenRepository;
import com.klef.dev.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ResetTokenRepository resetTokenRepository;

    @Override
    public User registerUser(User user) {
    	int uid = generateRandomUserId();
		user.setId(uid);
		String randomPassword = generateRandomPassword(8);
		user.setPassword(randomPassword);
		user.setRole("USER");
        return userRepository.save(user);
    }

    @Override
    public User checkuserlogin(String username, String password) {
    	return userRepository.findByUsernameAndPassword(username, password);
    }

    @Override
    public User getUserById(int id) {
        Optional<User> userOptional = userRepository.findById(id);
        return userOptional.orElse(null);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User updateUser(User user) {
        // The save method handles both create and update operations.
        return userRepository.save(user);
    }

    @Override
    public void deleteUserById(int id) {
        userRepository.deleteById(id);
    }
    
    @Override
	public String generateResetToken(String email) {
		Optional<User> artist = userRepository.findByEmail(email);
		if(artist.isPresent()) {
			String token = UUID.randomUUID().toString();
			
			ResetToken rt = new ResetToken();
			rt.setToken(token);
			rt.setEmail(email);
			rt.setCreatedAt(LocalDateTime.now());
			rt.setExpiresAt(LocalDateTime.now().plusMinutes(5)); // 5mins
			
			resetTokenRepository.save(rt);
			return token;
		}
		return null;
	}

	@Override
	public boolean validateResetToken(String token) {
		Optional<ResetToken> rt = resetTokenRepository.findByToken(token);
		return rt.isPresent() && !isTokenExpired(token);
	}

	@Override
	public boolean changePassword(User user, String oldPassword, String newPassword) {
		if(user.getPassword().equals(oldPassword)) {
			user.setPassword(newPassword);
			userRepository.save(user);
			return true;
		}
		return false;
	}

	@Override
	public void updatePassword(String token, String newPassword) {
		Optional<ResetToken> resetToken = resetTokenRepository.findByToken(token);
		if(resetToken.isPresent() && !isTokenExpired(token)) {
			User u = new User();
			u.setPassword(newPassword);
			userRepository.save(u);
			deleteResetToken(token);
		}
	}

	@Override
	public void deleteResetToken(String token) {
		resetTokenRepository.deleteByToken(token);
	}

	@Override
	public boolean isTokenExpired(String token) {
		Optional<ResetToken> rt = resetTokenRepository.findByToken(token);
		if(rt.isPresent()) {
			return rt.get().getExpiresAt().isBefore(LocalDateTime.now());
		}
		return true;
	}
	
	private int generateRandomUserId() {
		Random random = new Random();
		return 1000 + random.nextInt(9000);
	}
	
	private String generateRandomPassword(int length) {
		String upper = "ABCDEFHIJKLMNOPQRSTUVWXYZ";
		String lower = "abcdefghijklmnopqrstuvwxyz";
		String digits = "0123456789";
		String special = "~!@#$%^&*";
		String combined = upper + lower + digits + special;
		
		StringBuilder sb = new StringBuilder();
		Random random = new Random();
		
		sb.append(upper.charAt(random.nextInt(upper.length())));
		sb.append(lower.charAt(random.nextInt(lower.length())));
		sb.append(digits.charAt(random.nextInt(digits.length())));
		sb.append(special.charAt(random.nextInt(special.length())));
		
		for(int i = 4 ; i < length ; i++) {
			sb.append(combined.charAt(random.nextInt(combined.length())));
		}
		
		return sb.toString();
	}
	
	@Override
	public User findUserByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public Optional<User> findByEmail(String email) {
	    return userRepository.findByEmail(email);
	}
}
