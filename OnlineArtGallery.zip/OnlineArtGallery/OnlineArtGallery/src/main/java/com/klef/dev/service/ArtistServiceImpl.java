package com.klef.dev.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.dev.entity.Artist;
import com.klef.dev.entity.Artwork;
import com.klef.dev.entity.ResetToken;
import com.klef.dev.repository.ArtistRepository;
import com.klef.dev.repository.ArtworkRepository;
import com.klef.dev.repository.ResetTokenRepository;

@Service
public class ArtistServiceImpl implements ArtistService {

	@Autowired
	private ArtistRepository artistRepository;
	@Autowired
	private ArtworkRepository artworkRepository;
	@Autowired
	private ResetTokenRepository resetTokenRepository;

	@Override
	public Artist registerArtist(Artist artist) {
		int aid = generateRandomArtistId();
		artist.setId(aid);
		String randomPassword = generateRandomPassword(8);
		artist.setPassword(randomPassword);
		artist.setRole("ARTIST");
		return artistRepository.save(artist);
	}

	@Override
	public Artist checkartistlogin(String username, String password) {
		return artistRepository.findByUsernameAndPassword(username, password);
	}

	@Override
	public Artist getArtistById(int id) {
		Optional<Artist> artistOptional = artistRepository.findById(id);
		return artistOptional.orElse(null);
	}

	@Override
	public Artist updateArtist(Artist artist) {
		return artistRepository.save(artist);
	}

	@Override
	public void deleteArtistById(int id) {
		artistRepository.deleteById(id);
	}

	@Override
	public Artwork addArtwork(Artwork artwork) {
		return artworkRepository.save(artwork);
	}

	@Override
	public Artwork getArtworkById(int id) {
		Optional<Artwork> artworkOptional = artworkRepository.findById(id);
		return artworkOptional.orElse(null);
	}

	@Override
	public List<Artwork> getArtworksByArtistId(int artistId) {
		// You would typically add a custom query to your ArtworkRepository here
		// For simplicity, we are doing it in the service layer for now
		return artworkRepository.findByArtistId(artistId);
	}

	@Override
	public void deleteArtworkById(int id) {
		artworkRepository.deleteById(id);
	}

	@Override
	public String generateResetToken(String email) {
		Optional<Artist> artist = artistRepository.findByEmail(email);
		if (artist.isPresent()) {
			String token = UUID.randomUUID().toString();

			ResetToken rt = new ResetToken();
			rt.setToken(token);
			rt.setEmail(email);
			rt.setCreatedAt(LocalDateTime.now());
			rt.setExpiresAt(LocalDateTime.now().plusMinutes(5)); // 5mins

			resetTokenRepository.save(rt);
			return token;
		}
		return null;
	}

	@Override
	public boolean validateResetToken(String token) {
		Optional<ResetToken> rt = resetTokenRepository.findByToken(token);
		return rt.isPresent() && !isTokenExpired(token);
	}

	@Override
	public boolean changePassword(Artist artist, String oldPassword, String newPassword) {
		if (artist.getPassword().equals(oldPassword)) {
			artist.setPassword(newPassword);
			artistRepository.save(artist);
			return true;
		}
		return false;
	}

	@Override
	public void updatePassword(String token, String newPassword) {
		Optional<ResetToken> resetToken = resetTokenRepository.findByToken(token);
		if (resetToken.isPresent() && !isTokenExpired(token)) {
			Artist a = new Artist();
			a.setPassword(newPassword);
			artistRepository.save(a);
			deleteResetToken(token);
		}
	}

	@Override
	public void deleteResetToken(String token) {
		resetTokenRepository.deleteByToken(token);
	}

	@Override
	public boolean isTokenExpired(String token) {
		Optional<ResetToken> rt = resetTokenRepository.findByToken(token);
		if (rt.isPresent()) {
			return rt.get().getExpiresAt().isBefore(LocalDateTime.now());
		}
		return true;
	}

	private int generateRandomArtistId() {
		Random random = new Random();
		return 1000 + random.nextInt(9000);
	}

	private String generateRandomPassword(int length) {
		String upper = "ABCDEFHIJKLMNOPQRSTUVWXYZ";
		String lower = "abcdefghijklmnopqrstuvwxyz";
		String digits = "0123456789";
		String special = "~!@#$%^&*";
		String combined = upper + lower + digits + special;

		StringBuilder sb = new StringBuilder();
		Random random = new Random();

		sb.append(upper.charAt(random.nextInt(upper.length())));
		// upper.length() is 26
		// suppose random.nextInt(26) gives 7
		// so upper.charAt(7) is H
		// Then sb.append('H') will add this into String builder.
		sb.append(lower.charAt(random.nextInt(lower.length())));
		sb.append(digits.charAt(random.nextInt(digits.length())));
		sb.append(special.charAt(random.nextInt(special.length())));

		for (int i = 4; i < length; i++) {
			sb.append(combined.charAt(random.nextInt(combined.length())));
		}

		return sb.toString();
	}

	@Override
	public Optional<Artist> findByEmail(String email) {
		return artistRepository.findByEmail(email);
	}

	@Override
	public Artist findArtistByUsername(String username) {
		return artistRepository.findByUsername(username);
	}
}
