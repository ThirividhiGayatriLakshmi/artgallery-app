package com.klef.dev.service;

import com.klef.dev.entity.Admin;
import com.klef.dev.entity.Artwork;
import com.klef.dev.entity.Artist;
import com.klef.dev.entity.User;
import com.klef.dev.repository.AdminRepository;
import com.klef.dev.repository.UserRepository;
import com.klef.dev.repository.ArtistRepository;
import com.klef.dev.repository.ArtworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ArtistRepository artistRepository;
    @Autowired
    private ArtworkRepository artworkRepository;
    
    @Override
    public Admin checkadminlogin(String username, String password) {
    	return adminRepository.findByUsernameAndPassword(username, password);
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User getUserById(int id) {
        Optional<User> userOptional = userRepository.findById(id);
        return userOptional.orElse(null);
    }

    @Override
    public void deleteUserById(int id) {
        userRepository.deleteById(id);
    }

    @Override
    public List<Artist> getAllArtists() {
        return artistRepository.findAll();
    }

    @Override
    public Artist getArtistById(int id) {
        Optional<Artist> artistOptional = artistRepository.findById(id);
        return artistOptional.orElse(null);
    }

    @Override
    public void deleteArtistById(int id) {
        artistRepository.deleteById(id);
    }

    @Override
    public List<Artwork> getAllArtworks() {
        return artworkRepository.findAll();
    }

    @Override
    public Artwork getArtworkById(int id) {
        Optional<Artwork> artworkOptional = artworkRepository.findById(id);
        return artworkOptional.orElse(null);
    }

    @Override
    public void deleteArtworkById(int id) {
        artworkRepository.deleteById(id);
    }
}
