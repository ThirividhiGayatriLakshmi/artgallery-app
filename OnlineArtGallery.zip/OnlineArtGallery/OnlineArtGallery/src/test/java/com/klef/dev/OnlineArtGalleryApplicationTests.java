package com.klef.dev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineArtGalleryApplicationTests {

	@Test
	void contextLoads() {
	}

}
